int printf(const char* fmt, ...);

int main(int argc, char** argv) {

    int a = 2;
    while ((a=0));

    printf("%d\n", a);
    return 0;
}
