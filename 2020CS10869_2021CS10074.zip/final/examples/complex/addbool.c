int printf(const char* fmt, ...);

int main() {
    _Bool a = 1, b = 1;
    printf("%d\n", a+b);
    return 0;
}
