int main() {
    float f;
    double f; // redecl
    unsigned float u;
    return 0;
}
