int main() {

    printf("%d\n", a);
    return 0;

}
