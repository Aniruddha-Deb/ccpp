int printf(const char* fmt, ...);

int main() {
    int a = 5;
    int b = 81;
    printf("%d\n", a*2 + 23*5-6 - b/4);
    return 0;
}
