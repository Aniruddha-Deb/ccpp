/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output, and Bison version.  */
#define YYBISON 30802

/* Bison version string.  */
#define YYBISON_VERSION "3.8.2"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1




/* First part of user prologue.  */
#line 1 "src/c.y"

#include <cstdio>
#include <iostream>
#include <algorithm>
#include "ast.hpp"
#include "error.hpp"
using namespace std;

// stuff from flex that bison needs to know about:
extern "C" int yylex();
extern "C" FILE *yyin;
 
// #define YYDEBUG 1
// #define YYERROR_VERBOSE 1
void yyerror(ast::TranslationUnit* tu, const char *s);

void setpos(ast::Node *n, void* info);

#line 90 "src/c.tab.cpp"

# ifndef YY_CAST
#  ifdef __cplusplus
#   define YY_CAST(Type, Val) static_cast<Type> (Val)
#   define YY_REINTERPRET_CAST(Type, Val) reinterpret_cast<Type> (Val)
#  else
#   define YY_CAST(Type, Val) ((Type) (Val))
#   define YY_REINTERPRET_CAST(Type, Val) ((Type) (Val))
#  endif
# endif
# ifndef YY_NULLPTR
#  if defined __cplusplus
#   if 201103L <= __cplusplus
#    define YY_NULLPTR nullptr
#   else
#    define YY_NULLPTR 0
#   endif
#  else
#   define YY_NULLPTR ((void*)0)
#  endif
# endif

#include "c.tab.hpp"
/* Symbol kind.  */
enum yysymbol_kind_t
{
  YYSYMBOL_YYEMPTY = -2,
  YYSYMBOL_YYEOF = 0,                      /* "end of file"  */
  YYSYMBOL_YYerror = 1,                    /* error  */
  YYSYMBOL_YYUNDEF = 2,                    /* "invalid token"  */
  YYSYMBOL_FUNC_NAME = 3,                  /* FUNC_NAME  */
  YYSYMBOL_SIZEOF = 4,                     /* SIZEOF  */
  YYSYMBOL_IDENTIFIER = 5,                 /* IDENTIFIER  */
  YYSYMBOL_I_CONSTANT = 6,                 /* I_CONSTANT  */
  YYSYMBOL_F_CONSTANT = 7,                 /* F_CONSTANT  */
  YYSYMBOL_STRING_LITERAL = 8,             /* STRING_LITERAL  */
  YYSYMBOL_PTR_OP = 9,                     /* PTR_OP  */
  YYSYMBOL_INC_OP = 10,                    /* INC_OP  */
  YYSYMBOL_DEC_OP = 11,                    /* DEC_OP  */
  YYSYMBOL_LEFT_OP = 12,                   /* LEFT_OP  */
  YYSYMBOL_RIGHT_OP = 13,                  /* RIGHT_OP  */
  YYSYMBOL_LE_OP = 14,                     /* LE_OP  */
  YYSYMBOL_GE_OP = 15,                     /* GE_OP  */
  YYSYMBOL_EQ_OP = 16,                     /* EQ_OP  */
  YYSYMBOL_NE_OP = 17,                     /* NE_OP  */
  YYSYMBOL_AND_OP = 18,                    /* AND_OP  */
  YYSYMBOL_OR_OP = 19,                     /* OR_OP  */
  YYSYMBOL_MUL_ASSIGN = 20,                /* MUL_ASSIGN  */
  YYSYMBOL_DIV_ASSIGN = 21,                /* DIV_ASSIGN  */
  YYSYMBOL_MOD_ASSIGN = 22,                /* MOD_ASSIGN  */
  YYSYMBOL_ADD_ASSIGN = 23,                /* ADD_ASSIGN  */
  YYSYMBOL_SUB_ASSIGN = 24,                /* SUB_ASSIGN  */
  YYSYMBOL_LEFT_ASSIGN = 25,               /* LEFT_ASSIGN  */
  YYSYMBOL_RIGHT_ASSIGN = 26,              /* RIGHT_ASSIGN  */
  YYSYMBOL_AND_ASSIGN = 27,                /* AND_ASSIGN  */
  YYSYMBOL_XOR_ASSIGN = 28,                /* XOR_ASSIGN  */
  YYSYMBOL_OR_ASSIGN = 29,                 /* OR_ASSIGN  */
  YYSYMBOL_TYPEDEF_NAME = 30,              /* TYPEDEF_NAME  */
  YYSYMBOL_ENUMERATION_CONSTANT = 31,      /* ENUMERATION_CONSTANT  */
  YYSYMBOL_TYPEDEF = 32,                   /* TYPEDEF  */
  YYSYMBOL_EXTERN = 33,                    /* EXTERN  */
  YYSYMBOL_STATIC = 34,                    /* STATIC  */
  YYSYMBOL_AUTO = 35,                      /* AUTO  */
  YYSYMBOL_REGISTER = 36,                  /* REGISTER  */
  YYSYMBOL_INLINE = 37,                    /* INLINE  */
  YYSYMBOL_CONST = 38,                     /* CONST  */
  YYSYMBOL_RESTRICT = 39,                  /* RESTRICT  */
  YYSYMBOL_VOLATILE = 40,                  /* VOLATILE  */
  YYSYMBOL_BOOL = 41,                      /* BOOL  */
  YYSYMBOL_CHAR = 42,                      /* CHAR  */
  YYSYMBOL_SHORT = 43,                     /* SHORT  */
  YYSYMBOL_INT = 44,                       /* INT  */
  YYSYMBOL_LONG = 45,                      /* LONG  */
  YYSYMBOL_SIGNED = 46,                    /* SIGNED  */
  YYSYMBOL_UNSIGNED = 47,                  /* UNSIGNED  */
  YYSYMBOL_FLOAT = 48,                     /* FLOAT  */
  YYSYMBOL_DOUBLE = 49,                    /* DOUBLE  */
  YYSYMBOL_VOID = 50,                      /* VOID  */
  YYSYMBOL_COMPLEX = 51,                   /* COMPLEX  */
  YYSYMBOL_IMAGINARY = 52,                 /* IMAGINARY  */
  YYSYMBOL_STRUCT = 53,                    /* STRUCT  */
  YYSYMBOL_UNION = 54,                     /* UNION  */
  YYSYMBOL_ENUM = 55,                      /* ENUM  */
  YYSYMBOL_ELLIPSIS = 56,                  /* ELLIPSIS  */
  YYSYMBOL_CASE = 57,                      /* CASE  */
  YYSYMBOL_DEFAULT = 58,                   /* DEFAULT  */
  YYSYMBOL_IF = 59,                        /* IF  */
  YYSYMBOL_ELSE = 60,                      /* ELSE  */
  YYSYMBOL_SWITCH = 61,                    /* SWITCH  */
  YYSYMBOL_WHILE = 62,                     /* WHILE  */
  YYSYMBOL_DO = 63,                        /* DO  */
  YYSYMBOL_FOR = 64,                       /* FOR  */
  YYSYMBOL_GOTO = 65,                      /* GOTO  */
  YYSYMBOL_CONTINUE = 66,                  /* CONTINUE  */
  YYSYMBOL_BREAK = 67,                     /* BREAK  */
  YYSYMBOL_RETURN = 68,                    /* RETURN  */
  YYSYMBOL_ALIGNAS = 69,                   /* ALIGNAS  */
  YYSYMBOL_ALIGNOF = 70,                   /* ALIGNOF  */
  YYSYMBOL_ATOMIC = 71,                    /* ATOMIC  */
  YYSYMBOL_GENERIC = 72,                   /* GENERIC  */
  YYSYMBOL_NORETURN = 73,                  /* NORETURN  */
  YYSYMBOL_STATIC_ASSERT = 74,             /* STATIC_ASSERT  */
  YYSYMBOL_THREAD_LOCAL = 75,              /* THREAD_LOCAL  */
  YYSYMBOL_76_ = 76,                       /* '('  */
  YYSYMBOL_77_ = 77,                       /* ')'  */
  YYSYMBOL_78_ = 78,                       /* '['  */
  YYSYMBOL_79_ = 79,                       /* ']'  */
  YYSYMBOL_80_ = 80,                       /* '.'  */
  YYSYMBOL_81_ = 81,                       /* ','  */
  YYSYMBOL_82_ = 82,                       /* '&'  */
  YYSYMBOL_83_ = 83,                       /* '*'  */
  YYSYMBOL_84_ = 84,                       /* '+'  */
  YYSYMBOL_85_ = 85,                       /* '-'  */
  YYSYMBOL_86_ = 86,                       /* '~'  */
  YYSYMBOL_87_ = 87,                       /* '!'  */
  YYSYMBOL_88_ = 88,                       /* '/'  */
  YYSYMBOL_89_ = 89,                       /* '%'  */
  YYSYMBOL_90_ = 90,                       /* '<'  */
  YYSYMBOL_91_ = 91,                       /* '>'  */
  YYSYMBOL_92_ = 92,                       /* '^'  */
  YYSYMBOL_93_ = 93,                       /* '|'  */
  YYSYMBOL_94_ = 94,                       /* '?'  */
  YYSYMBOL_95_ = 95,                       /* ':'  */
  YYSYMBOL_96_ = 96,                       /* '='  */
  YYSYMBOL_97_ = 97,                       /* ';'  */
  YYSYMBOL_98_ = 98,                       /* '{'  */
  YYSYMBOL_99_ = 99,                       /* '}'  */
  YYSYMBOL_YYACCEPT = 100,                 /* $accept  */
  YYSYMBOL_primary_expression = 101,       /* primary_expression  */
  YYSYMBOL_constant = 102,                 /* constant  */
  YYSYMBOL_string = 103,                   /* string  */
  YYSYMBOL_postfix_expression = 104,       /* postfix_expression  */
  YYSYMBOL_argument_expression_list = 105, /* argument_expression_list  */
  YYSYMBOL_unary_expression = 106,         /* unary_expression  */
  YYSYMBOL_unary_operator = 107,           /* unary_operator  */
  YYSYMBOL_multiplicative_expression = 108, /* multiplicative_expression  */
  YYSYMBOL_additive_expression = 109,      /* additive_expression  */
  YYSYMBOL_shift_expression = 110,         /* shift_expression  */
  YYSYMBOL_relational_expression = 111,    /* relational_expression  */
  YYSYMBOL_equality_expression = 112,      /* equality_expression  */
  YYSYMBOL_and_expression = 113,           /* and_expression  */
  YYSYMBOL_exclusive_or_expression = 114,  /* exclusive_or_expression  */
  YYSYMBOL_inclusive_or_expression = 115,  /* inclusive_or_expression  */
  YYSYMBOL_logical_and_expression = 116,   /* logical_and_expression  */
  YYSYMBOL_logical_or_expression = 117,    /* logical_or_expression  */
  YYSYMBOL_conditional_expression = 118,   /* conditional_expression  */
  YYSYMBOL_assignment_expression = 119,    /* assignment_expression  */
  YYSYMBOL_assignment_operator = 120,      /* assignment_operator  */
  YYSYMBOL_expression = 121,               /* expression  */
  YYSYMBOL_constant_expression = 122,      /* constant_expression  */
  YYSYMBOL_declaration = 123,              /* declaration  */
  YYSYMBOL_declaration_specifiers = 124,   /* declaration_specifiers  */
  YYSYMBOL_init_declarator_list = 125,     /* init_declarator_list  */
  YYSYMBOL_init_declarator = 126,          /* init_declarator  */
  YYSYMBOL_pointer_list = 127,             /* pointer_list  */
  YYSYMBOL_storage_class_specifier = 128,  /* storage_class_specifier  */
  YYSYMBOL_type_specifier = 129,           /* type_specifier  */
  YYSYMBOL_type_qualifier = 130,           /* type_qualifier  */
  YYSYMBOL_function_specifier = 131,       /* function_specifier  */
  YYSYMBOL_function_parameter_list = 132,  /* function_parameter_list  */
  YYSYMBOL_parameter_list = 133,           /* parameter_list  */
  YYSYMBOL_pure_declaration = 134,         /* pure_declaration  */
  YYSYMBOL_statement = 135,                /* statement  */
  YYSYMBOL_declaration_statement = 136,    /* declaration_statement  */
  YYSYMBOL_labeled_statement = 137,        /* labeled_statement  */
  YYSYMBOL_compound_statement = 138,       /* compound_statement  */
  YYSYMBOL_block_item_list = 139,          /* block_item_list  */
  YYSYMBOL_expression_statement = 140,     /* expression_statement  */
  YYSYMBOL_selection_statement = 141,      /* selection_statement  */
  YYSYMBOL_iteration_statement = 142,      /* iteration_statement  */
  YYSYMBOL_jump_statement = 143,           /* jump_statement  */
  YYSYMBOL_translation_unit = 144,         /* translation_unit  */
  YYSYMBOL_function_definition = 145,      /* function_definition  */
  YYSYMBOL_function_declaration = 146      /* function_declaration  */
};
typedef enum yysymbol_kind_t yysymbol_kind_t;




#ifdef short
# undef short
#endif

/* On compilers that do not define __PTRDIFF_MAX__ etc., make sure
   <limits.h> and (if available) <stdint.h> are included
   so that the code can choose integer types of a good width.  */

#ifndef __PTRDIFF_MAX__
# include <limits.h> /* INFRINGES ON USER NAME SPACE */
# if defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stdint.h> /* INFRINGES ON USER NAME SPACE */
#  define YY_STDINT_H
# endif
#endif

/* Narrow types that promote to a signed type and that can represent a
   signed or unsigned integer of at least N bits.  In tables they can
   save space and decrease cache pressure.  Promoting to a signed type
   helps avoid bugs in integer arithmetic.  */

#ifdef __INT_LEAST8_MAX__
typedef __INT_LEAST8_TYPE__ yytype_int8;
#elif defined YY_STDINT_H
typedef int_least8_t yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef __INT_LEAST16_MAX__
typedef __INT_LEAST16_TYPE__ yytype_int16;
#elif defined YY_STDINT_H
typedef int_least16_t yytype_int16;
#else
typedef short yytype_int16;
#endif

/* Work around bug in HP-UX 11.23, which defines these macros
   incorrectly for preprocessor constants.  This workaround can likely
   be removed in 2023, as HPE has promised support for HP-UX 11.23
   (aka HP-UX 11i v2) only through the end of 2022; see Table 2 of
   <https://h20195.www2.hpe.com/V2/getpdf.aspx/4AA4-7673ENW.pdf>.  */
#ifdef __hpux
# undef UINT_LEAST8_MAX
# undef UINT_LEAST16_MAX
# define UINT_LEAST8_MAX 255
# define UINT_LEAST16_MAX 65535
#endif

#if defined __UINT_LEAST8_MAX__ && __UINT_LEAST8_MAX__ <= __INT_MAX__
typedef __UINT_LEAST8_TYPE__ yytype_uint8;
#elif (!defined __UINT_LEAST8_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST8_MAX <= INT_MAX)
typedef uint_least8_t yytype_uint8;
#elif !defined __UINT_LEAST8_MAX__ && UCHAR_MAX <= INT_MAX
typedef unsigned char yytype_uint8;
#else
typedef short yytype_uint8;
#endif

#if defined __UINT_LEAST16_MAX__ && __UINT_LEAST16_MAX__ <= __INT_MAX__
typedef __UINT_LEAST16_TYPE__ yytype_uint16;
#elif (!defined __UINT_LEAST16_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST16_MAX <= INT_MAX)
typedef uint_least16_t yytype_uint16;
#elif !defined __UINT_LEAST16_MAX__ && USHRT_MAX <= INT_MAX
typedef unsigned short yytype_uint16;
#else
typedef int yytype_uint16;
#endif

#ifndef YYPTRDIFF_T
# if defined __PTRDIFF_TYPE__ && defined __PTRDIFF_MAX__
#  define YYPTRDIFF_T __PTRDIFF_TYPE__
#  define YYPTRDIFF_MAXIMUM __PTRDIFF_MAX__
# elif defined PTRDIFF_MAX
#  ifndef ptrdiff_t
#   include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  endif
#  define YYPTRDIFF_T ptrdiff_t
#  define YYPTRDIFF_MAXIMUM PTRDIFF_MAX
# else
#  define YYPTRDIFF_T long
#  define YYPTRDIFF_MAXIMUM LONG_MAX
# endif
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned
# endif
#endif

#define YYSIZE_MAXIMUM                                  \
  YY_CAST (YYPTRDIFF_T,                                 \
           (YYPTRDIFF_MAXIMUM < YY_CAST (YYSIZE_T, -1)  \
            ? YYPTRDIFF_MAXIMUM                         \
            : YY_CAST (YYSIZE_T, -1)))

#define YYSIZEOF(X) YY_CAST (YYPTRDIFF_T, sizeof (X))


/* Stored state numbers (used for stacks). */
typedef yytype_uint8 yy_state_t;

/* State numbers in computations.  */
typedef int yy_state_fast_t;

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif


#ifndef YY_ATTRIBUTE_PURE
# if defined __GNUC__ && 2 < __GNUC__ + (96 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_PURE __attribute__ ((__pure__))
# else
#  define YY_ATTRIBUTE_PURE
# endif
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# if defined __GNUC__ && 2 < __GNUC__ + (7 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_UNUSED __attribute__ ((__unused__))
# else
#  define YY_ATTRIBUTE_UNUSED
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YY_USE(E) ((void) (E))
#else
# define YY_USE(E) /* empty */
#endif

/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
#if defined __GNUC__ && ! defined __ICC && 406 <= __GNUC__ * 100 + __GNUC_MINOR__
# if __GNUC__ * 100 + __GNUC_MINOR__ < 407
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")
# else
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")              \
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# endif
# define YY_IGNORE_MAYBE_UNINITIALIZED_END      \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif

#if defined __cplusplus && defined __GNUC__ && ! defined __ICC && 6 <= __GNUC__
# define YY_IGNORE_USELESS_CAST_BEGIN                          \
    _Pragma ("GCC diagnostic push")                            \
    _Pragma ("GCC diagnostic ignored \"-Wuseless-cast\"")
# define YY_IGNORE_USELESS_CAST_END            \
    _Pragma ("GCC diagnostic pop")
#endif
#ifndef YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_END
#endif


#define YY_ASSERT(E) ((void) (0 && (E)))

#if 1

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* 1 */

#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined YYLTYPE_IS_TRIVIAL && YYLTYPE_IS_TRIVIAL \
             && defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yy_state_t yyss_alloc;
  YYSTYPE yyvs_alloc;
  YYLTYPE yyls_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (YYSIZEOF (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (YYSIZEOF (yy_state_t) + YYSIZEOF (YYSTYPE) \
             + YYSIZEOF (YYLTYPE)) \
      + 2 * YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYPTRDIFF_T yynewbytes;                                         \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * YYSIZEOF (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / YYSIZEOF (*yyptr);                        \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, YY_CAST (YYSIZE_T, (Count)) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYPTRDIFF_T yyi;                      \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  45
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   625

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  100
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  47
/* YYNRULES -- Number of rules.  */
#define YYNRULES  160
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  253

/* YYMAXUTOK -- Last valid token kind.  */
#define YYMAXUTOK   330


/* YYTRANSLATE(TOKEN-NUM) -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, with out-of-bounds checking.  */
#define YYTRANSLATE(YYX)                                \
  (0 <= (YYX) && (YYX) <= YYMAXUTOK                     \
   ? YY_CAST (yysymbol_kind_t, yytranslate[YYX])        \
   : YYSYMBOL_YYUNDEF)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex.  */
static const yytype_int8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,    87,     2,     2,     2,    89,    82,     2,
      76,    77,    83,    84,    81,    85,    80,    88,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,    95,    97,
      90,    96,    91,    94,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,    78,     2,    79,    92,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,    98,    93,    99,    86,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75
};

#if YYDEBUG
/* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_int16 yyrline[] =
{
       0,   133,   133,   134,   135,   136,   140,   141,   145,   149,
     150,   151,   152,   153,   154,   155,   156,   160,   161,   165,
     166,   167,   168,   172,   173,   174,   175,   176,   177,   181,
     182,   183,   184,   188,   189,   190,   194,   195,   196,   200,
     201,   202,   203,   204,   208,   209,   210,   214,   215,   219,
     220,   224,   225,   229,   230,   234,   235,   239,   240,   244,
     245,   249,   250,   251,   252,   253,   254,   255,   256,   257,
     258,   259,   263,   264,   268,   274,   275,   279,   280,   281,
     282,   283,   284,   285,   286,   290,   291,   295,   296,   297,
     298,   302,   303,   308,   309,   310,   311,   312,   316,   317,
     318,   319,   320,   321,   322,   323,   324,   325,   326,   327,
     331,   332,   333,   334,   338,   339,   343,   344,   348,   349,
     353,   354,   360,   361,   362,   363,   364,   365,   366,   370,
     373,   374,   375,   379,   380,   384,   385,   388,   389,   393,
     394,   395,   399,   400,   404,   405,   406,   407,   408,   414,
     415,   416,   417,   418,   419,   423,   424,   425,   429,   430,
     431
};
#endif

/** Accessing symbol of state STATE.  */
#define YY_ACCESSING_SYMBOL(State) YY_CAST (yysymbol_kind_t, yystos[State])

#if 1
/* The user-facing name of the symbol whose (internal) number is
   YYSYMBOL.  No bounds checking.  */
static const char *yysymbol_name (yysymbol_kind_t yysymbol) YY_ATTRIBUTE_UNUSED;

/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "\"end of file\"", "error", "\"invalid token\"", "FUNC_NAME", "SIZEOF",
  "IDENTIFIER", "I_CONSTANT", "F_CONSTANT", "STRING_LITERAL", "PTR_OP",
  "INC_OP", "DEC_OP", "LEFT_OP", "RIGHT_OP", "LE_OP", "GE_OP", "EQ_OP",
  "NE_OP", "AND_OP", "OR_OP", "MUL_ASSIGN", "DIV_ASSIGN", "MOD_ASSIGN",
  "ADD_ASSIGN", "SUB_ASSIGN", "LEFT_ASSIGN", "RIGHT_ASSIGN", "AND_ASSIGN",
  "XOR_ASSIGN", "OR_ASSIGN", "TYPEDEF_NAME", "ENUMERATION_CONSTANT",
  "TYPEDEF", "EXTERN", "STATIC", "AUTO", "REGISTER", "INLINE", "CONST",
  "RESTRICT", "VOLATILE", "BOOL", "CHAR", "SHORT", "INT", "LONG", "SIGNED",
  "UNSIGNED", "FLOAT", "DOUBLE", "VOID", "COMPLEX", "IMAGINARY", "STRUCT",
  "UNION", "ENUM", "ELLIPSIS", "CASE", "DEFAULT", "IF", "ELSE", "SWITCH",
  "WHILE", "DO", "FOR", "GOTO", "CONTINUE", "BREAK", "RETURN", "ALIGNAS",
  "ALIGNOF", "ATOMIC", "GENERIC", "NORETURN", "STATIC_ASSERT",
  "THREAD_LOCAL", "'('", "')'", "'['", "']'", "'.'", "','", "'&'", "'*'",
  "'+'", "'-'", "'~'", "'!'", "'/'", "'%'", "'<'", "'>'", "'^'", "'|'",
  "'?'", "':'", "'='", "';'", "'{'", "'}'", "$accept",
  "primary_expression", "constant", "string", "postfix_expression",
  "argument_expression_list", "unary_expression", "unary_operator",
  "multiplicative_expression", "additive_expression", "shift_expression",
  "relational_expression", "equality_expression", "and_expression",
  "exclusive_or_expression", "inclusive_or_expression",
  "logical_and_expression", "logical_or_expression",
  "conditional_expression", "assignment_expression", "assignment_operator",
  "expression", "constant_expression", "declaration",
  "declaration_specifiers", "init_declarator_list", "init_declarator",
  "pointer_list", "storage_class_specifier", "type_specifier",
  "type_qualifier", "function_specifier", "function_parameter_list",
  "parameter_list", "pure_declaration", "statement",
  "declaration_statement", "labeled_statement", "compound_statement",
  "block_item_list", "expression_statement", "selection_statement",
  "iteration_statement", "jump_statement", "translation_unit",
  "function_definition", "function_declaration", YY_NULLPTR
};

static const char *
yysymbol_name (yysymbol_kind_t yysymbol)
{
  return yytname[yysymbol];
}
#endif

#define YYPACT_NINF (-139)

#define yypact_value_is_default(Yyn) \
  ((Yyn) == YYPACT_NINF)

#define YYTABLE_NINF (-122)

#define yytable_value_is_error(Yyn) \
  0

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
static const yytype_int16 yypact[] =
{
     550,  -139,  -139,  -139,  -139,  -139,  -139,  -139,  -139,  -139,
    -139,  -139,  -139,  -139,  -139,  -139,  -139,  -139,  -139,  -139,
    -139,  -139,  -139,  -139,  -139,    30,   550,   550,   550,   550,
     -27,   393,  -139,  -139,   -62,   -28,  -139,   -74,  -139,    16,
    -139,  -139,  -139,  -139,   462,  -139,  -139,  -139,  -139,   407,
    -139,    -4,  -139,   -56,    46,   -11,     6,    67,    58,  -139,
    -139,  -139,  -139,  -139,   407,   407,   407,  -139,  -139,  -139,
    -139,  -139,  -139,  -139,  -139,  -139,    41,    44,   407,   -64,
      31,   113,     1,   133,    95,    92,   105,   170,    -6,  -139,
    -139,   108,  -139,   196,   407,    54,  -139,   124,  -139,  -139,
     200,    56,   507,  -139,  -139,  -139,   -21,   211,  -139,  -139,
      -2,   407,   214,  -139,  -139,  -139,  -139,  -139,  -139,  -139,
    -139,  -139,  -139,  -139,   407,  -139,   407,   407,   407,   407,
     407,   407,   407,   407,   407,   407,   407,   407,   407,   407,
     407,   407,   407,   407,   407,   128,  -139,  -139,  -139,   130,
     407,   132,   152,   153,   158,   324,   232,   141,   142,   225,
    -139,  -139,   -55,  -139,    39,  -139,  -139,  -139,  -139,   207,
    -139,  -139,  -139,  -139,  -139,  -139,  -139,  -139,  -139,  -139,
     407,  -139,  -139,   -20,  -139,    64,  -139,  -139,  -139,  -139,
    -139,  -139,   -64,   -64,    31,    31,   113,   113,   113,   113,
       1,     1,   133,    95,    92,   105,   170,    33,   324,  -139,
     165,   324,   407,   407,   407,   199,   166,  -139,  -139,  -139,
     -38,  -139,  -139,  -139,  -139,  -139,   407,  -139,   407,  -139,
     324,  -139,   -19,    43,    60,   191,  -139,  -139,  -139,  -139,
    -139,   324,   324,   324,   407,   217,  -139,  -139,    61,   324,
     174,  -139,  -139
};

/* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
   Performed when YYTABLE does not specify something else to do.  Zero
   means the default is an error.  */
static const yytype_uint8 yydefact[] =
{
       0,    93,    94,    96,    97,   114,   110,   111,   112,   107,
      99,   100,   101,   102,   105,   106,   103,   104,    98,   108,
     109,   113,   115,    95,   151,     0,    78,    80,    82,    84,
       0,     0,   149,   150,    90,    92,    75,     0,    85,     0,
      77,    79,    81,    83,     0,     1,   154,   152,   153,     0,
      91,     0,    76,    89,    98,     0,     0,     0,   117,   118,
       2,     6,     7,     8,     0,     0,     0,    23,    24,    25,
      26,    27,    28,     9,     3,     4,    19,    29,     0,    33,
      36,    39,    44,    47,    49,    51,    53,    55,    57,    59,
      88,    90,    86,     0,     0,     0,   159,     0,   156,   121,
       0,     0,     0,    20,    21,    72,     0,     0,    15,    16,
       0,     0,     0,    62,    63,    64,    65,    66,    67,    68,
      69,    70,    71,    61,     0,    22,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    89,    87,   160,   157,     2,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     137,   134,     0,   129,     0,   135,   123,   122,   124,     0,
     125,   126,   127,   128,   120,   158,   155,   116,   119,     5,
       0,    14,    11,     0,    17,     0,    13,    60,    30,    31,
      32,    29,    34,    35,    37,    38,    42,    43,    40,    41,
      45,    46,    48,    50,    52,    54,    56,     0,     0,    74,
       0,     0,     0,     0,     0,     0,     0,   145,   146,   147,
       0,   138,   133,   136,    73,    12,     0,    10,     0,   130,
       0,   132,     0,     0,     0,     0,   144,   148,    18,    58,
     131,     0,     0,     0,     0,   140,   141,   142,     0,     0,
       0,   139,   143
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -139,  -139,  -139,  -139,  -139,  -139,   -32,  -139,    26,    62,
    -105,    65,   140,   144,   145,   139,   154,  -139,  -138,   -47,
    -139,   -66,  -139,    22,    10,  -139,   234,    -8,  -139,  -139,
    -139,  -139,  -139,  -139,   -26,   107,  -139,  -139,   125,  -139,
    -139,  -139,  -139,  -139,  -139,   256,   257
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_uint8 yydefgoto[] =
{
       0,    73,    74,    75,    76,   183,    77,    78,    79,    80,
      81,    82,    83,    84,    85,    86,    87,    88,    89,   105,
     124,   162,   210,   163,   164,    37,    38,    93,    26,    27,
      28,    29,    57,    58,    30,   165,   166,   167,   168,   169,
     170,   171,   172,   173,    31,    32,    33
};

/* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule whose
   number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_int16 yytable[] =
{
     106,    91,    90,    60,    61,    62,    63,    51,    64,    65,
      25,    99,   209,   143,  -121,   133,   134,    39,    59,   126,
    -120,    53,    24,    52,   127,   128,   180,    50,   196,   197,
     198,   199,   103,   104,    49,    34,    40,    41,    42,    43,
      94,    25,   221,   180,    91,   185,   125,   146,   100,    44,
     107,   108,   109,    46,    56,    35,   179,   225,   241,   237,
     180,   226,   180,   184,   113,   114,   115,   116,   117,   118,
     119,   120,   121,   122,    66,   182,   178,   187,   207,    35,
      67,    68,    69,    70,    71,    72,    96,    97,   144,    35,
     239,   135,   136,   220,   188,   189,   190,   191,   191,   191,
     191,   191,   191,   191,   191,   191,   191,   191,   191,   191,
     191,   191,    56,    35,   180,   129,   130,   110,   191,   111,
     242,   112,    35,    95,   180,   131,   132,    36,   228,   149,
      61,    62,    63,   224,    64,    65,    36,   243,   250,   102,
     123,   180,   180,   227,   101,   180,   232,   233,   234,   137,
     138,   147,    97,   175,    97,   192,   193,     1,     2,     3,
       4,     5,     6,     7,     8,     9,    10,    11,    12,    13,
      14,    15,    16,    17,    18,    19,    20,   139,   248,   238,
      98,   150,   151,   152,   140,   153,   154,   155,   142,   156,
     157,   158,   159,   194,   195,    21,   191,    22,   141,    23,
      66,   145,   200,   201,    49,   174,    67,    68,    69,    70,
      71,    72,   149,    61,    62,    63,   181,    64,    65,   186,
     148,   160,    97,   161,    94,   208,   176,   211,   212,   213,
      60,    61,    62,    63,   214,    64,    65,   216,   217,   218,
       1,     2,     3,     4,     5,     6,     7,     8,     9,    10,
      11,    12,    13,    14,    15,    16,    17,    18,    19,    20,
     230,   235,   215,   236,   150,   151,   152,   244,   153,   154,
     155,   252,   156,   157,   158,   159,   223,   249,    21,   202,
      22,   205,    23,    66,   203,    92,   204,    47,    48,    67,
      68,    69,    70,    71,    72,     0,     0,   206,     0,     0,
       0,    66,     0,     0,   160,    97,   222,    67,    68,    69,
      70,    71,    72,     0,     0,   229,     0,     0,   231,     0,
       0,     0,   219,     0,     0,     0,     0,     0,     0,   149,
      61,    62,    63,     0,    64,    65,     0,   240,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   245,   246,
     247,     0,     0,     0,     0,     0,   251,     1,     2,     3,
       4,     5,     6,     7,     8,     9,    10,    11,    12,    13,
      14,    15,    16,    17,    18,    19,    20,     0,     0,     0,
       0,   150,   151,   152,     0,   153,   154,   155,     0,   156,
     157,   158,   159,    45,     0,    21,     0,    22,     0,    23,
      66,     0,     0,     0,     0,     0,    67,    68,    69,    70,
      71,    72,    60,    61,    62,    63,     0,    64,    65,     0,
       0,   160,    97,     0,     0,     0,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    21,     0,    22,     0,    23,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    66,     0,     0,     0,     0,     0,    67,
      68,    69,    70,    71,    72,     1,     2,     3,     4,     5,
       6,     7,     8,     9,    10,    11,    12,    13,    14,    15,
      16,    17,    54,    19,    20,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    21,     0,    22,     0,    23,     0,    55,
       1,     2,     3,     4,     5,     6,     7,     8,     9,    10,
      11,    12,    13,    14,    15,    16,    17,    18,    19,    20,
       0,     0,     0,   177,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    21,     0,
      22,     0,    23,     1,     2,     3,     4,     5,     6,     7,
       8,     9,    10,    11,    12,    13,    14,    15,    16,    17,
      18,    19,    20,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    21,     0,    22,     0,    23
};

static const yytype_int16 yycheck[] =
{
      66,     5,    49,     5,     6,     7,     8,    81,    10,    11,
       0,     5,   150,    19,    76,    14,    15,    25,    44,    83,
      76,     5,     0,    97,    88,    89,    81,    35,   133,   134,
     135,   136,    64,    65,    96,     5,    26,    27,    28,    29,
      96,    31,    97,    81,     5,   111,    78,    94,    56,    76,
       9,    10,    11,    31,    44,    83,    77,    77,    77,    97,
      81,    81,    81,   110,    20,    21,    22,    23,    24,    25,
      26,    27,    28,    29,    76,    77,   102,   124,   144,    83,
      82,    83,    84,    85,    86,    87,    97,    98,    94,    83,
     228,    90,    91,   159,   126,   127,   128,   129,   130,   131,
     132,   133,   134,   135,   136,   137,   138,   139,   140,   141,
     142,   143,   102,    83,    81,    84,    85,    76,   150,    78,
      77,    80,    83,    77,    81,    12,    13,    97,    95,     5,
       6,     7,     8,   180,    10,    11,    97,    77,    77,    81,
      96,    81,    81,    79,    77,    81,   212,   213,   214,    16,
      17,    97,    98,    97,    98,   129,   130,    33,    34,    35,
      36,    37,    38,    39,    40,    41,    42,    43,    44,    45,
      46,    47,    48,    49,    50,    51,    52,    82,   244,   226,
      55,    57,    58,    59,    92,    61,    62,    63,    18,    65,
      66,    67,    68,   131,   132,    71,   228,    73,    93,    75,
      76,     5,   137,   138,    96,     5,    82,    83,    84,    85,
      86,    87,     5,     6,     7,     8,     5,    10,    11,     5,
      95,    97,    98,    99,    96,    95,   101,    95,    76,    76,
       5,     6,     7,     8,    76,    10,    11,     5,    97,    97,
      33,    34,    35,    36,    37,    38,    39,    40,    41,    42,
      43,    44,    45,    46,    47,    48,    49,    50,    51,    52,
      95,    62,   155,    97,    57,    58,    59,    76,    61,    62,
      63,    97,    65,    66,    67,    68,   169,    60,    71,   139,
      73,   142,    75,    76,   140,    51,   141,    31,    31,    82,
      83,    84,    85,    86,    87,    -1,    -1,   143,    -1,    -1,
      -1,    76,    -1,    -1,    97,    98,    99,    82,    83,    84,
      85,    86,    87,    -1,    -1,   208,    -1,    -1,   211,    -1,
      -1,    -1,    97,    -1,    -1,    -1,    -1,    -1,    -1,     5,
       6,     7,     8,    -1,    10,    11,    -1,   230,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   241,   242,
     243,    -1,    -1,    -1,    -1,    -1,   249,    33,    34,    35,
      36,    37,    38,    39,    40,    41,    42,    43,    44,    45,
      46,    47,    48,    49,    50,    51,    52,    -1,    -1,    -1,
      -1,    57,    58,    59,    -1,    61,    62,    63,    -1,    65,
      66,    67,    68,     0,    -1,    71,    -1,    73,    -1,    75,
      76,    -1,    -1,    -1,    -1,    -1,    82,    83,    84,    85,
      86,    87,     5,     6,     7,     8,    -1,    10,    11,    -1,
      -1,    97,    98,    -1,    -1,    -1,    33,    34,    35,    36,
      37,    38,    39,    40,    41,    42,    43,    44,    45,    46,
      47,    48,    49,    50,    51,    52,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    71,    -1,    73,    -1,    75,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    76,    -1,    -1,    -1,    -1,    -1,    82,
      83,    84,    85,    86,    87,    33,    34,    35,    36,    37,
      38,    39,    40,    41,    42,    43,    44,    45,    46,    47,
      48,    49,    50,    51,    52,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    71,    -1,    73,    -1,    75,    -1,    77,
      33,    34,    35,    36,    37,    38,    39,    40,    41,    42,
      43,    44,    45,    46,    47,    48,    49,    50,    51,    52,
      -1,    -1,    -1,    56,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    71,    -1,
      73,    -1,    75,    33,    34,    35,    36,    37,    38,    39,
      40,    41,    42,    43,    44,    45,    46,    47,    48,    49,
      50,    51,    52,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    71,    -1,    73,    -1,    75
};

/* YYSTOS[STATE-NUM] -- The symbol kind of the accessing symbol of
   state STATE-NUM.  */
static const yytype_uint8 yystos[] =
{
       0,    33,    34,    35,    36,    37,    38,    39,    40,    41,
      42,    43,    44,    45,    46,    47,    48,    49,    50,    51,
      52,    71,    73,    75,   123,   124,   128,   129,   130,   131,
     134,   144,   145,   146,     5,    83,    97,   125,   126,   127,
     124,   124,   124,   124,    76,     0,   123,   145,   146,    96,
     127,    81,    97,     5,    50,    77,   124,   132,   133,   134,
       5,     6,     7,     8,    10,    11,    76,    82,    83,    84,
      85,    86,    87,   101,   102,   103,   104,   106,   107,   108,
     109,   110,   111,   112,   113,   114,   115,   116,   117,   118,
     119,     5,   126,   127,    96,    77,    97,    98,   138,     5,
     127,    77,    81,   106,   106,   119,   121,     9,    10,    11,
      76,    78,    80,    20,    21,    22,    23,    24,    25,    26,
      27,    28,    29,    96,   120,   106,    83,    88,    89,    84,
      85,    12,    13,    14,    15,    90,    91,    16,    17,    82,
      92,    93,    18,    19,    94,     5,   119,    97,   138,     5,
      57,    58,    59,    61,    62,    63,    65,    66,    67,    68,
      97,    99,   121,   123,   124,   135,   136,   137,   138,   139,
     140,   141,   142,   143,     5,    97,   138,    56,   134,    77,
      81,     5,    77,   105,   119,   121,     5,   119,   106,   106,
     106,   106,   108,   108,   109,   109,   110,   110,   110,   110,
     111,   111,   112,   113,   114,   115,   116,   121,    95,   118,
     122,    95,    76,    76,    76,   135,     5,    97,    97,    97,
     121,    97,    99,   135,   119,    77,    81,    79,    95,   135,
      95,   135,   121,   121,   121,    62,    97,    97,   119,   118,
     135,    77,    77,    77,    76,   135,   135,   135,   121,    60,
      77,   135,    97
};

/* YYR1[RULE-NUM] -- Symbol kind of the left-hand side of rule RULE-NUM.  */
static const yytype_uint8 yyr1[] =
{
       0,   100,   101,   101,   101,   101,   102,   102,   103,   104,
     104,   104,   104,   104,   104,   104,   104,   105,   105,   106,
     106,   106,   106,   107,   107,   107,   107,   107,   107,   108,
     108,   108,   108,   109,   109,   109,   110,   110,   110,   111,
     111,   111,   111,   111,   112,   112,   112,   113,   113,   114,
     114,   115,   115,   116,   116,   117,   117,   118,   118,   119,
     119,   120,   120,   120,   120,   120,   120,   120,   120,   120,
     120,   120,   121,   121,   122,   123,   123,   124,   124,   124,
     124,   124,   124,   124,   124,   125,   125,   126,   126,   126,
     126,   127,   127,   128,   128,   128,   128,   128,   129,   129,
     129,   129,   129,   129,   129,   129,   129,   129,   129,   129,
     130,   130,   130,   130,   131,   131,   132,   132,   133,   133,
     134,   134,   135,   135,   135,   135,   135,   135,   135,   136,
     137,   137,   137,   138,   138,   139,   139,   140,   140,   141,
     141,   141,   142,   142,   143,   143,   143,   143,   143,   144,
     144,   144,   144,   144,   144,   145,   145,   145,   146,   146,
     146
};

/* YYR2[RULE-NUM] -- Number of symbols on the right-hand side of rule RULE-NUM.  */
static const yytype_int8 yyr2[] =
{
       0,     2,     1,     1,     1,     3,     1,     1,     1,     1,
       4,     3,     4,     3,     3,     2,     2,     1,     3,     1,
       2,     2,     2,     1,     1,     1,     1,     1,     1,     1,
       3,     3,     3,     1,     3,     3,     1,     3,     3,     1,
       3,     3,     3,     3,     1,     3,     3,     1,     3,     1,
       3,     1,     3,     1,     3,     1,     3,     1,     5,     1,
       3,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     3,     1,     2,     3,     2,     1,     2,
       1,     2,     1,     2,     1,     1,     3,     4,     3,     2,
       1,     2,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     3,     1,     1,     3,
       3,     2,     1,     1,     1,     1,     1,     1,     1,     1,
       3,     4,     3,     3,     2,     1,     2,     1,     2,     7,
       5,     5,     5,     7,     3,     2,     2,     2,     3,     1,
       1,     1,     2,     2,     2,     5,     4,     5,     5,     4,
       5
};


enum { YYENOMEM = -2 };

#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = YYEMPTY)

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYNOMEM         goto yyexhaustedlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                    \
  do                                                              \
    if (yychar == YYEMPTY)                                        \
      {                                                           \
        yychar = (Token);                                         \
        yylval = (Value);                                         \
        YYPOPSTACK (yylen);                                       \
        yystate = *yyssp;                                         \
        goto yybackup;                                            \
      }                                                           \
    else                                                          \
      {                                                           \
        yyerror (tu, YY_("syntax error: cannot back up")); \
        YYERROR;                                                  \
      }                                                           \
  while (0)

/* Backward compatibility with an undocumented macro.
   Use YYerror or YYUNDEF. */
#define YYERRCODE YYUNDEF

/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)                                \
    do                                                                  \
      if (N)                                                            \
        {                                                               \
          (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;        \
          (Current).first_column = YYRHSLOC (Rhs, 1).first_column;      \
          (Current).last_line    = YYRHSLOC (Rhs, N).last_line;         \
          (Current).last_column  = YYRHSLOC (Rhs, N).last_column;       \
        }                                                               \
      else                                                              \
        {                                                               \
          (Current).first_line   = (Current).last_line   =              \
            YYRHSLOC (Rhs, 0).last_line;                                \
          (Current).first_column = (Current).last_column =              \
            YYRHSLOC (Rhs, 0).last_column;                              \
        }                                                               \
    while (0)
#endif

#define YYRHSLOC(Rhs, K) ((Rhs)[K])


/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)


/* YYLOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

# ifndef YYLOCATION_PRINT

#  if defined YY_LOCATION_PRINT

   /* Temporary convenience wrapper in case some people defined the
      undocumented and private YY_LOCATION_PRINT macros.  */
#   define YYLOCATION_PRINT(File, Loc)  YY_LOCATION_PRINT(File, *(Loc))

#  elif defined YYLTYPE_IS_TRIVIAL && YYLTYPE_IS_TRIVIAL

/* Print *YYLOCP on YYO.  Private, do not rely on its existence. */

YY_ATTRIBUTE_UNUSED
static int
yy_location_print_ (FILE *yyo, YYLTYPE const * const yylocp)
{
  int res = 0;
  int end_col = 0 != yylocp->last_column ? yylocp->last_column - 1 : 0;
  if (0 <= yylocp->first_line)
    {
      res += YYFPRINTF (yyo, "%d", yylocp->first_line);
      if (0 <= yylocp->first_column)
        res += YYFPRINTF (yyo, ".%d", yylocp->first_column);
    }
  if (0 <= yylocp->last_line)
    {
      if (yylocp->first_line < yylocp->last_line)
        {
          res += YYFPRINTF (yyo, "-%d", yylocp->last_line);
          if (0 <= end_col)
            res += YYFPRINTF (yyo, ".%d", end_col);
        }
      else if (0 <= end_col && yylocp->first_column < end_col)
        res += YYFPRINTF (yyo, "-%d", end_col);
    }
  return res;
}

#   define YYLOCATION_PRINT  yy_location_print_

    /* Temporary convenience wrapper in case some people defined the
       undocumented and private YY_LOCATION_PRINT macros.  */
#   define YY_LOCATION_PRINT(File, Loc)  YYLOCATION_PRINT(File, &(Loc))

#  else

#   define YYLOCATION_PRINT(File, Loc) ((void) 0)
    /* Temporary convenience wrapper in case some people defined the
       undocumented and private YY_LOCATION_PRINT macros.  */
#   define YY_LOCATION_PRINT  YYLOCATION_PRINT

#  endif
# endif /* !defined YYLOCATION_PRINT */


# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Kind, Value, Location, tu); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*-----------------------------------.
| Print this symbol's value on YYO.  |
`-----------------------------------*/

static void
yy_symbol_value_print (FILE *yyo,
                       yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep, YYLTYPE const * const yylocationp, ast::TranslationUnit* tu)
{
  FILE *yyoutput = yyo;
  YY_USE (yyoutput);
  YY_USE (yylocationp);
  YY_USE (tu);
  if (!yyvaluep)
    return;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/*---------------------------.
| Print this symbol on YYO.  |
`---------------------------*/

static void
yy_symbol_print (FILE *yyo,
                 yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep, YYLTYPE const * const yylocationp, ast::TranslationUnit* tu)
{
  YYFPRINTF (yyo, "%s %s (",
             yykind < YYNTOKENS ? "token" : "nterm", yysymbol_name (yykind));

  YYLOCATION_PRINT (yyo, yylocationp);
  YYFPRINTF (yyo, ": ");
  yy_symbol_value_print (yyo, yykind, yyvaluep, yylocationp, tu);
  YYFPRINTF (yyo, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yy_state_t *yybottom, yy_state_t *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yy_state_t *yyssp, YYSTYPE *yyvsp, YYLTYPE *yylsp,
                 int yyrule, ast::TranslationUnit* tu)
{
  int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %d):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       YY_ACCESSING_SYMBOL (+yyssp[yyi + 1 - yynrhs]),
                       &yyvsp[(yyi + 1) - (yynrhs)],
                       &(yylsp[(yyi + 1) - (yynrhs)]), tu);
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, yylsp, Rule, tu); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args) ((void) 0)
# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif


/* Context of a parse error.  */
typedef struct
{
  yy_state_t *yyssp;
  yysymbol_kind_t yytoken;
  YYLTYPE *yylloc;
} yypcontext_t;

/* Put in YYARG at most YYARGN of the expected tokens given the
   current YYCTX, and return the number of tokens stored in YYARG.  If
   YYARG is null, return the number of expected tokens (guaranteed to
   be less than YYNTOKENS).  Return YYENOMEM on memory exhaustion.
   Return 0 if there are more than YYARGN expected tokens, yet fill
   YYARG up to YYARGN. */
static int
yypcontext_expected_tokens (const yypcontext_t *yyctx,
                            yysymbol_kind_t yyarg[], int yyargn)
{
  /* Actual size of YYARG. */
  int yycount = 0;
  int yyn = yypact[+*yyctx->yyssp];
  if (!yypact_value_is_default (yyn))
    {
      /* Start YYX at -YYN if negative to avoid negative indexes in
         YYCHECK.  In other words, skip the first -YYN actions for
         this state because they are default actions.  */
      int yyxbegin = yyn < 0 ? -yyn : 0;
      /* Stay within bounds of both yycheck and yytname.  */
      int yychecklim = YYLAST - yyn + 1;
      int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
      int yyx;
      for (yyx = yyxbegin; yyx < yyxend; ++yyx)
        if (yycheck[yyx + yyn] == yyx && yyx != YYSYMBOL_YYerror
            && !yytable_value_is_error (yytable[yyx + yyn]))
          {
            if (!yyarg)
              ++yycount;
            else if (yycount == yyargn)
              return 0;
            else
              yyarg[yycount++] = YY_CAST (yysymbol_kind_t, yyx);
          }
    }
  if (yyarg && yycount == 0 && 0 < yyargn)
    yyarg[0] = YYSYMBOL_YYEMPTY;
  return yycount;
}




#ifndef yystrlen
# if defined __GLIBC__ && defined _STRING_H
#  define yystrlen(S) (YY_CAST (YYPTRDIFF_T, strlen (S)))
# else
/* Return the length of YYSTR.  */
static YYPTRDIFF_T
yystrlen (const char *yystr)
{
  YYPTRDIFF_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
# endif
#endif

#ifndef yystpcpy
# if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#  define yystpcpy stpcpy
# else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
yystpcpy (char *yydest, const char *yysrc)
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
# endif
#endif

#ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYPTRDIFF_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYPTRDIFF_T yyn = 0;
      char const *yyp = yystr;
      for (;;)
        switch (*++yyp)
          {
          case '\'':
          case ',':
            goto do_not_strip_quotes;

          case '\\':
            if (*++yyp != '\\')
              goto do_not_strip_quotes;
            else
              goto append;

          append:
          default:
            if (yyres)
              yyres[yyn] = *yyp;
            yyn++;
            break;

          case '"':
            if (yyres)
              yyres[yyn] = '\0';
            return yyn;
          }
    do_not_strip_quotes: ;
    }

  if (yyres)
    return yystpcpy (yyres, yystr) - yyres;
  else
    return yystrlen (yystr);
}
#endif


static int
yy_syntax_error_arguments (const yypcontext_t *yyctx,
                           yysymbol_kind_t yyarg[], int yyargn)
{
  /* Actual size of YYARG. */
  int yycount = 0;
  /* There are many possibilities here to consider:
     - If this state is a consistent state with a default action, then
       the only way this function was invoked is if the default action
       is an error action.  In that case, don't check for expected
       tokens because there are none.
     - The only way there can be no lookahead present (in yychar) is if
       this state is a consistent state with a default action.  Thus,
       detecting the absence of a lookahead is sufficient to determine
       that there is no unexpected or expected token to report.  In that
       case, just report a simple "syntax error".
     - Don't assume there isn't a lookahead just because this state is a
       consistent state with a default action.  There might have been a
       previous inconsistent state, consistent state with a non-default
       action, or user semantic action that manipulated yychar.
     - Of course, the expected token list depends on states to have
       correct lookahead information, and it depends on the parser not
       to perform extra reductions after fetching a lookahead from the
       scanner and before detecting a syntax error.  Thus, state merging
       (from LALR or IELR) and default reductions corrupt the expected
       token list.  However, the list is correct for canonical LR with
       one exception: it will still contain any token that will not be
       accepted due to an error action in a later state.
  */
  if (yyctx->yytoken != YYSYMBOL_YYEMPTY)
    {
      int yyn;
      if (yyarg)
        yyarg[yycount] = yyctx->yytoken;
      ++yycount;
      yyn = yypcontext_expected_tokens (yyctx,
                                        yyarg ? yyarg + 1 : yyarg, yyargn - 1);
      if (yyn == YYENOMEM)
        return YYENOMEM;
      else
        yycount += yyn;
    }
  return yycount;
}

/* Copy into *YYMSG, which is of size *YYMSG_ALLOC, an error message
   about the unexpected token YYTOKEN for the state stack whose top is
   YYSSP.

   Return 0 if *YYMSG was successfully written.  Return -1 if *YYMSG is
   not large enough to hold the message.  In that case, also set
   *YYMSG_ALLOC to the required number of bytes.  Return YYENOMEM if the
   required number of bytes is too large to store.  */
static int
yysyntax_error (YYPTRDIFF_T *yymsg_alloc, char **yymsg,
                const yypcontext_t *yyctx)
{
  enum { YYARGS_MAX = 5 };
  /* Internationalized format string. */
  const char *yyformat = YY_NULLPTR;
  /* Arguments of yyformat: reported tokens (one for the "unexpected",
     one per "expected"). */
  yysymbol_kind_t yyarg[YYARGS_MAX];
  /* Cumulated lengths of YYARG.  */
  YYPTRDIFF_T yysize = 0;

  /* Actual size of YYARG. */
  int yycount = yy_syntax_error_arguments (yyctx, yyarg, YYARGS_MAX);
  if (yycount == YYENOMEM)
    return YYENOMEM;

  switch (yycount)
    {
#define YYCASE_(N, S)                       \
      case N:                               \
        yyformat = S;                       \
        break
    default: /* Avoid compiler warnings. */
      YYCASE_(0, YY_("syntax error"));
      YYCASE_(1, YY_("syntax error, unexpected %s"));
      YYCASE_(2, YY_("syntax error, unexpected %s, expecting %s"));
      YYCASE_(3, YY_("syntax error, unexpected %s, expecting %s or %s"));
      YYCASE_(4, YY_("syntax error, unexpected %s, expecting %s or %s or %s"));
      YYCASE_(5, YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s"));
#undef YYCASE_
    }

  /* Compute error message size.  Don't count the "%s"s, but reserve
     room for the terminator.  */
  yysize = yystrlen (yyformat) - 2 * yycount + 1;
  {
    int yyi;
    for (yyi = 0; yyi < yycount; ++yyi)
      {
        YYPTRDIFF_T yysize1
          = yysize + yytnamerr (YY_NULLPTR, yytname[yyarg[yyi]]);
        if (yysize <= yysize1 && yysize1 <= YYSTACK_ALLOC_MAXIMUM)
          yysize = yysize1;
        else
          return YYENOMEM;
      }
  }

  if (*yymsg_alloc < yysize)
    {
      *yymsg_alloc = 2 * yysize;
      if (! (yysize <= *yymsg_alloc
             && *yymsg_alloc <= YYSTACK_ALLOC_MAXIMUM))
        *yymsg_alloc = YYSTACK_ALLOC_MAXIMUM;
      return -1;
    }

  /* Avoid sprintf, as that infringes on the user's name space.
     Don't have undefined behavior even if the translation
     produced a string with the wrong number of "%s"s.  */
  {
    char *yyp = *yymsg;
    int yyi = 0;
    while ((*yyp = *yyformat) != '\0')
      if (*yyp == '%' && yyformat[1] == 's' && yyi < yycount)
        {
          yyp += yytnamerr (yyp, yytname[yyarg[yyi++]]);
          yyformat += 2;
        }
      else
        {
          ++yyp;
          ++yyformat;
        }
  }
  return 0;
}


/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg,
            yysymbol_kind_t yykind, YYSTYPE *yyvaluep, YYLTYPE *yylocationp, ast::TranslationUnit* tu)
{
  YY_USE (yyvaluep);
  YY_USE (yylocationp);
  YY_USE (tu);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yykind, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/* Lookahead token kind.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;
/* Location data for the lookahead symbol.  */
YYLTYPE yylloc
# if defined YYLTYPE_IS_TRIVIAL && YYLTYPE_IS_TRIVIAL
  = { 1, 1, 1, 1 }
# endif
;
/* Number of syntax errors so far.  */
int yynerrs;




/*----------.
| yyparse.  |
`----------*/

int
yyparse (ast::TranslationUnit* tu)
{
    yy_state_fast_t yystate = 0;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus = 0;

    /* Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* Their size.  */
    YYPTRDIFF_T yystacksize = YYINITDEPTH;

    /* The state stack: array, bottom, top.  */
    yy_state_t yyssa[YYINITDEPTH];
    yy_state_t *yyss = yyssa;
    yy_state_t *yyssp = yyss;

    /* The semantic value stack: array, bottom, top.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs = yyvsa;
    YYSTYPE *yyvsp = yyvs;

    /* The location stack: array, bottom, top.  */
    YYLTYPE yylsa[YYINITDEPTH];
    YYLTYPE *yyls = yylsa;
    YYLTYPE *yylsp = yyls;

  int yyn;
  /* The return value of yyparse.  */
  int yyresult;
  /* Lookahead symbol kind.  */
  yysymbol_kind_t yytoken = YYSYMBOL_YYEMPTY;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;
  YYLTYPE yyloc;

  /* The locations where the error started and ended.  */
  YYLTYPE yyerror_range[3];

  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYPTRDIFF_T yymsg_alloc = sizeof yymsgbuf;

#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N), yylsp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yychar = YYEMPTY; /* Cause a token to be read.  */

  yylsp[0] = yylloc;
  goto yysetstate;


/*------------------------------------------------------------.
| yynewstate -- push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;


/*--------------------------------------------------------------------.
| yysetstate -- set current state (the top of the stack) to yystate.  |
`--------------------------------------------------------------------*/
yysetstate:
  YYDPRINTF ((stderr, "Entering state %d\n", yystate));
  YY_ASSERT (0 <= yystate && yystate < YYNSTATES);
  YY_IGNORE_USELESS_CAST_BEGIN
  *yyssp = YY_CAST (yy_state_t, yystate);
  YY_IGNORE_USELESS_CAST_END
  YY_STACK_PRINT (yyss, yyssp);

  if (yyss + yystacksize - 1 <= yyssp)
#if !defined yyoverflow && !defined YYSTACK_RELOCATE
    YYNOMEM;
#else
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYPTRDIFF_T yysize = yyssp - yyss + 1;

# if defined yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        yy_state_t *yyss1 = yyss;
        YYSTYPE *yyvs1 = yyvs;
        YYLTYPE *yyls1 = yyls;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * YYSIZEOF (*yyssp),
                    &yyvs1, yysize * YYSIZEOF (*yyvsp),
                    &yyls1, yysize * YYSIZEOF (*yylsp),
                    &yystacksize);
        yyss = yyss1;
        yyvs = yyvs1;
        yyls = yyls1;
      }
# else /* defined YYSTACK_RELOCATE */
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        YYNOMEM;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yy_state_t *yyss1 = yyss;
        union yyalloc *yyptr =
          YY_CAST (union yyalloc *,
                   YYSTACK_ALLOC (YY_CAST (YYSIZE_T, YYSTACK_BYTES (yystacksize))));
        if (! yyptr)
          YYNOMEM;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
        YYSTACK_RELOCATE (yyls_alloc, yyls);
#  undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;
      yylsp = yyls + yysize - 1;

      YY_IGNORE_USELESS_CAST_BEGIN
      YYDPRINTF ((stderr, "Stack size increased to %ld\n",
                  YY_CAST (long, yystacksize)));
      YY_IGNORE_USELESS_CAST_END

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }
#endif /* !defined yyoverflow && !defined YYSTACK_RELOCATE */


  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;


/*-----------.
| yybackup.  |
`-----------*/
yybackup:
  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either empty, or end-of-input, or a valid lookahead.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token\n"));
      yychar = yylex ();
    }

  if (yychar <= YYEOF)
    {
      yychar = YYEOF;
      yytoken = YYSYMBOL_YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else if (yychar == YYerror)
    {
      /* The scanner already issued an error message, process directly
         to error recovery.  But do not keep the error token as
         lookahead, it is too special and may lead us to an endless
         loop in error recovery. */
      yychar = YYUNDEF;
      yytoken = YYSYMBOL_YYerror;
      yyerror_range[1] = yylloc;
      goto yyerrlab1;
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);
  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END
  *++yylsp = yylloc;

  /* Discard the shifted token.  */
  yychar = YYEMPTY;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];

  /* Default location. */
  YYLLOC_DEFAULT (yyloc, (yylsp - yylen), yylen);
  yyerror_range[1] = yyloc;
  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
  case 2: /* primary_expression: IDENTIFIER  */
#line 133 "src/c.y"
                 { (yyval.ast_expression) = new ast::Identifier((yyvsp[0].str)); setpos((yyval.ast_expression), &(yyloc)); }
#line 1890 "src/c.tab.cpp"
    break;

  case 3: /* primary_expression: constant  */
#line 134 "src/c.y"
               { (yyval.ast_expression) = (yyvsp[0].ast_expression); }
#line 1896 "src/c.tab.cpp"
    break;

  case 4: /* primary_expression: string  */
#line 135 "src/c.y"
             { (yyval.ast_expression) = (yyvsp[0].ast_expression); }
#line 1902 "src/c.tab.cpp"
    break;

  case 5: /* primary_expression: '(' expression ')'  */
#line 136 "src/c.y"
                         { (yyval.ast_expression) = (yyvsp[-1].ast_expression); setpos((yyval.ast_expression), &(yyloc)); }
#line 1908 "src/c.tab.cpp"
    break;

  case 6: /* constant: I_CONSTANT  */
#line 140 "src/c.y"
                 { (yyval.ast_expression) = new ast::Literal((yyvsp[0].str), ast::LT_INT_LIKE); setpos((yyval.ast_expression), &(yyloc)); }
#line 1914 "src/c.tab.cpp"
    break;

  case 7: /* constant: F_CONSTANT  */
#line 141 "src/c.y"
                 { (yyval.ast_expression) = new ast::Literal((yyvsp[0].str), ast::LT_FLOAT_LIKE);setpos((yyval.ast_expression), &(yyloc)); }
#line 1920 "src/c.tab.cpp"
    break;

  case 8: /* string: STRING_LITERAL  */
#line 145 "src/c.y"
                     { (yyval.ast_expression) = new ast::Literal((yyvsp[0].str), ast::LT_STRING); setpos((yyval.ast_expression), &(yyloc)); }
#line 1926 "src/c.tab.cpp"
    break;

  case 9: /* postfix_expression: primary_expression  */
#line 149 "src/c.y"
                         { (yyval.ast_expression) = (yyvsp[0].ast_expression); }
#line 1932 "src/c.tab.cpp"
    break;

  case 11: /* postfix_expression: postfix_expression '(' ')'  */
#line 151 "src/c.y"
                                 { (yyval.ast_expression) = new ast::FunctionInvocationExpression((yyvsp[-2].ast_expression)); setpos((yyval.ast_expression), &(yyloc)); }
#line 1938 "src/c.tab.cpp"
    break;

  case 12: /* postfix_expression: postfix_expression '(' argument_expression_list ')'  */
#line 152 "src/c.y"
                                                          { (yyval.ast_expression) = new ast::FunctionInvocationExpression((yyvsp[-3].ast_expression), (yyvsp[-1].ast_expression_list)); setpos((yyval.ast_expression), &(yyloc)); }
#line 1944 "src/c.tab.cpp"
    break;

  case 15: /* postfix_expression: postfix_expression INC_OP  */
#line 155 "src/c.y"
                                { (yyval.ast_expression) = ast::allocateUnaryExpression(ast::OP_POST_INCR, (yyvsp[-1].ast_expression)); setpos((yyval.ast_expression), &(yyloc)); }
#line 1950 "src/c.tab.cpp"
    break;

  case 16: /* postfix_expression: postfix_expression DEC_OP  */
#line 156 "src/c.y"
                                { (yyval.ast_expression) = ast::allocateUnaryExpression(ast::OP_POST_DECR, (yyvsp[-1].ast_expression)); setpos((yyval.ast_expression), &(yyloc)); }
#line 1956 "src/c.tab.cpp"
    break;

  case 17: /* argument_expression_list: assignment_expression  */
#line 160 "src/c.y"
                            { (yyval.ast_expression_list) = new vector<ast::Expression*>(); (yyval.ast_expression_list)->push_back((yyvsp[0].ast_expression)); }
#line 1962 "src/c.tab.cpp"
    break;

  case 18: /* argument_expression_list: argument_expression_list ',' assignment_expression  */
#line 161 "src/c.y"
                                                         { (yyvsp[-2].ast_expression_list)->push_back((yyvsp[0].ast_expression)); (yyval.ast_expression_list) = (yyvsp[-2].ast_expression_list); }
#line 1968 "src/c.tab.cpp"
    break;

  case 19: /* unary_expression: postfix_expression  */
#line 165 "src/c.y"
                         { (yyval.ast_expression) = (yyvsp[0].ast_expression); }
#line 1974 "src/c.tab.cpp"
    break;

  case 20: /* unary_expression: INC_OP unary_expression  */
#line 166 "src/c.y"
                              { (yyval.ast_expression) = ast::allocateUnaryExpression(ast::OP_PRE_INCR, (yyvsp[0].ast_expression)); setpos((yyval.ast_expression), &(yyloc)); }
#line 1980 "src/c.tab.cpp"
    break;

  case 21: /* unary_expression: DEC_OP unary_expression  */
#line 167 "src/c.y"
                              { (yyval.ast_expression) = ast::allocateUnaryExpression(ast::OP_PRE_DECR, (yyvsp[0].ast_expression)); setpos((yyval.ast_expression), &(yyloc)); }
#line 1986 "src/c.tab.cpp"
    break;

  case 22: /* unary_expression: unary_operator unary_expression  */
#line 168 "src/c.y"
                                      { (yyval.ast_expression) = ast::allocateUnaryExpression((yyvsp[-1].ast_operator), (yyvsp[0].ast_expression)); setpos((yyval.ast_expression), &(yyloc)); }
#line 1992 "src/c.tab.cpp"
    break;

  case 23: /* unary_operator: '&'  */
#line 172 "src/c.y"
          { (yyval.ast_operator) = ast::OP_AND; }
#line 1998 "src/c.tab.cpp"
    break;

  case 24: /* unary_operator: '*'  */
#line 173 "src/c.y"
          { (yyval.ast_operator) = ast::OP_DEREF; }
#line 2004 "src/c.tab.cpp"
    break;

  case 25: /* unary_operator: '+'  */
#line 174 "src/c.y"
          { (yyval.ast_operator) = ast::OP_UNARY_PLUS; }
#line 2010 "src/c.tab.cpp"
    break;

  case 26: /* unary_operator: '-'  */
#line 175 "src/c.y"
          { (yyval.ast_operator) = ast::OP_UNARY_MINUS; }
#line 2016 "src/c.tab.cpp"
    break;

  case 27: /* unary_operator: '~'  */
#line 176 "src/c.y"
          { (yyval.ast_operator) = ast::OP_NOT; }
#line 2022 "src/c.tab.cpp"
    break;

  case 28: /* unary_operator: '!'  */
#line 177 "src/c.y"
          { (yyval.ast_operator) = ast::OP_BOOL_NOT; }
#line 2028 "src/c.tab.cpp"
    break;

  case 29: /* multiplicative_expression: unary_expression  */
#line 181 "src/c.y"
                       { (yyval.ast_expression) = (yyvsp[0].ast_expression); }
#line 2034 "src/c.tab.cpp"
    break;

  case 30: /* multiplicative_expression: multiplicative_expression '*' unary_expression  */
#line 182 "src/c.y"
                                                     { (yyval.ast_expression) = ast::allocateBinaryExpression((yyvsp[-2].ast_expression), ast::OP_MUL, (yyvsp[0].ast_expression)); setpos((yyval.ast_expression), &(yyloc)); }
#line 2040 "src/c.tab.cpp"
    break;

  case 31: /* multiplicative_expression: multiplicative_expression '/' unary_expression  */
#line 183 "src/c.y"
                                                     { (yyval.ast_expression) = ast::allocateBinaryExpression((yyvsp[-2].ast_expression), ast::OP_DIV, (yyvsp[0].ast_expression)); setpos((yyval.ast_expression), &(yyloc)); }
#line 2046 "src/c.tab.cpp"
    break;

  case 32: /* multiplicative_expression: multiplicative_expression '%' unary_expression  */
#line 184 "src/c.y"
                                                     { (yyval.ast_expression) = ast::allocateBinaryExpression((yyvsp[-2].ast_expression), ast::OP_MOD, (yyvsp[0].ast_expression)); setpos((yyval.ast_expression), &(yyloc)); }
#line 2052 "src/c.tab.cpp"
    break;

  case 33: /* additive_expression: multiplicative_expression  */
#line 188 "src/c.y"
                                { (yyval.ast_expression) = (yyvsp[0].ast_expression); }
#line 2058 "src/c.tab.cpp"
    break;

  case 34: /* additive_expression: additive_expression '+' multiplicative_expression  */
#line 189 "src/c.y"
                                                        { (yyval.ast_expression) = ast::allocateBinaryExpression((yyvsp[-2].ast_expression), ast::OP_ADD, (yyvsp[0].ast_expression)); setpos((yyval.ast_expression), &(yyloc)); }
#line 2064 "src/c.tab.cpp"
    break;

  case 35: /* additive_expression: additive_expression '-' multiplicative_expression  */
#line 190 "src/c.y"
                                                        { (yyval.ast_expression) = ast::allocateBinaryExpression((yyvsp[-2].ast_expression), ast::OP_SUB, (yyvsp[0].ast_expression)); setpos((yyval.ast_expression), &(yyloc)); }
#line 2070 "src/c.tab.cpp"
    break;

  case 36: /* shift_expression: additive_expression  */
#line 194 "src/c.y"
                          { (yyval.ast_expression) = (yyvsp[0].ast_expression); }
#line 2076 "src/c.tab.cpp"
    break;

  case 37: /* shift_expression: shift_expression LEFT_OP additive_expression  */
#line 195 "src/c.y"
                                                   { (yyval.ast_expression) = ast::allocateBinaryExpression((yyvsp[-2].ast_expression), ast::OP_LSHIFT, (yyvsp[0].ast_expression)); setpos((yyval.ast_expression), &(yyloc)); }
#line 2082 "src/c.tab.cpp"
    break;

  case 38: /* shift_expression: shift_expression RIGHT_OP additive_expression  */
#line 196 "src/c.y"
                                                    { (yyval.ast_expression) = ast::allocateBinaryExpression((yyvsp[-2].ast_expression), ast::OP_RSHIFT, (yyvsp[0].ast_expression)); setpos((yyval.ast_expression), &(yyloc)); }
#line 2088 "src/c.tab.cpp"
    break;

  case 39: /* relational_expression: shift_expression  */
#line 200 "src/c.y"
                       { (yyval.ast_expression) = (yyvsp[0].ast_expression); }
#line 2094 "src/c.tab.cpp"
    break;

  case 40: /* relational_expression: relational_expression '<' shift_expression  */
#line 201 "src/c.y"
                                                 { (yyval.ast_expression) = ast::allocateBinaryExpression((yyvsp[-2].ast_expression), ast::OP_LT, (yyvsp[0].ast_expression)); setpos((yyval.ast_expression), &(yyloc)); }
#line 2100 "src/c.tab.cpp"
    break;

  case 41: /* relational_expression: relational_expression '>' shift_expression  */
#line 202 "src/c.y"
                                                 { (yyval.ast_expression) = ast::allocateBinaryExpression((yyvsp[-2].ast_expression), ast::OP_GT, (yyvsp[0].ast_expression)); setpos((yyval.ast_expression), &(yyloc)); }
#line 2106 "src/c.tab.cpp"
    break;

  case 42: /* relational_expression: relational_expression LE_OP shift_expression  */
#line 203 "src/c.y"
                                                   { (yyval.ast_expression) = ast::allocateBinaryExpression((yyvsp[-2].ast_expression), ast::OP_LE, (yyvsp[0].ast_expression)); setpos((yyval.ast_expression), &(yyloc)); }
#line 2112 "src/c.tab.cpp"
    break;

  case 43: /* relational_expression: relational_expression GE_OP shift_expression  */
#line 204 "src/c.y"
                                                   { (yyval.ast_expression) = ast::allocateBinaryExpression((yyvsp[-2].ast_expression), ast::OP_GE, (yyvsp[0].ast_expression)); setpos((yyval.ast_expression), &(yyloc)); }
#line 2118 "src/c.tab.cpp"
    break;

  case 44: /* equality_expression: relational_expression  */
#line 208 "src/c.y"
                            { (yyval.ast_expression) = (yyvsp[0].ast_expression); }
#line 2124 "src/c.tab.cpp"
    break;

  case 45: /* equality_expression: equality_expression EQ_OP relational_expression  */
#line 209 "src/c.y"
                                                      { (yyval.ast_expression) = ast::allocateBinaryExpression((yyvsp[-2].ast_expression), ast::OP_EQ, (yyvsp[0].ast_expression)); setpos((yyval.ast_expression), &(yyloc)); }
#line 2130 "src/c.tab.cpp"
    break;

  case 46: /* equality_expression: equality_expression NE_OP relational_expression  */
#line 210 "src/c.y"
                                                      { (yyval.ast_expression) = ast::allocateBinaryExpression((yyvsp[-2].ast_expression), ast::OP_NE, (yyvsp[0].ast_expression)); setpos((yyval.ast_expression), &(yyloc)); }
#line 2136 "src/c.tab.cpp"
    break;

  case 47: /* and_expression: equality_expression  */
#line 214 "src/c.y"
                          { (yyval.ast_expression) = (yyvsp[0].ast_expression); }
#line 2142 "src/c.tab.cpp"
    break;

  case 48: /* and_expression: and_expression '&' equality_expression  */
#line 215 "src/c.y"
                                             { (yyval.ast_expression) = ast::allocateBinaryExpression((yyvsp[-2].ast_expression), ast::OP_AND, (yyvsp[0].ast_expression)); setpos((yyval.ast_expression), &(yyloc)); }
#line 2148 "src/c.tab.cpp"
    break;

  case 49: /* exclusive_or_expression: and_expression  */
#line 219 "src/c.y"
                     { (yyval.ast_expression) = (yyvsp[0].ast_expression); }
#line 2154 "src/c.tab.cpp"
    break;

  case 50: /* exclusive_or_expression: exclusive_or_expression '^' and_expression  */
#line 220 "src/c.y"
                                                 { (yyval.ast_expression) = ast::allocateBinaryExpression((yyvsp[-2].ast_expression), ast::OP_XOR, (yyvsp[0].ast_expression)); setpos((yyval.ast_expression), &(yyloc)); }
#line 2160 "src/c.tab.cpp"
    break;

  case 51: /* inclusive_or_expression: exclusive_or_expression  */
#line 224 "src/c.y"
                              { (yyval.ast_expression) = (yyvsp[0].ast_expression); }
#line 2166 "src/c.tab.cpp"
    break;

  case 52: /* inclusive_or_expression: inclusive_or_expression '|' exclusive_or_expression  */
#line 225 "src/c.y"
                                                          { (yyval.ast_expression) = ast::allocateBinaryExpression((yyvsp[-2].ast_expression), ast::OP_OR, (yyvsp[0].ast_expression)); setpos((yyval.ast_expression), &(yyloc)); }
#line 2172 "src/c.tab.cpp"
    break;

  case 53: /* logical_and_expression: inclusive_or_expression  */
#line 229 "src/c.y"
                              { (yyval.ast_expression) = (yyvsp[0].ast_expression); }
#line 2178 "src/c.tab.cpp"
    break;

  case 54: /* logical_and_expression: logical_and_expression AND_OP inclusive_or_expression  */
#line 230 "src/c.y"
                                                            { (yyval.ast_expression) = ast::allocateBinaryExpression((yyvsp[-2].ast_expression), ast::OP_BOOL_AND, (yyvsp[0].ast_expression)); setpos((yyval.ast_expression), &(yyloc)); }
#line 2184 "src/c.tab.cpp"
    break;

  case 55: /* logical_or_expression: logical_and_expression  */
#line 234 "src/c.y"
                             { (yyval.ast_expression) = (yyvsp[0].ast_expression); }
#line 2190 "src/c.tab.cpp"
    break;

  case 56: /* logical_or_expression: logical_or_expression OR_OP logical_and_expression  */
#line 235 "src/c.y"
                                                         { (yyval.ast_expression) = ast::allocateBinaryExpression((yyvsp[-2].ast_expression), ast::OP_BOOL_OR, (yyvsp[0].ast_expression)); setpos((yyval.ast_expression), &(yyloc)); }
#line 2196 "src/c.tab.cpp"
    break;

  case 57: /* conditional_expression: logical_or_expression  */
#line 239 "src/c.y"
                            { (yyval.ast_expression) = (yyvsp[0].ast_expression); }
#line 2202 "src/c.tab.cpp"
    break;

  case 58: /* conditional_expression: logical_or_expression '?' expression ':' conditional_expression  */
#line 240 "src/c.y"
                                                                      { (yyval.ast_expression) = new ast::TernaryExpression((yyvsp[-4].ast_expression), (yyvsp[-2].ast_expression), (yyvsp[0].ast_expression)); setpos((yyval.ast_expression), &(yyloc)); }
#line 2208 "src/c.tab.cpp"
    break;

  case 59: /* assignment_expression: conditional_expression  */
#line 244 "src/c.y"
                             { (yyval.ast_expression) = (yyvsp[0].ast_expression); }
#line 2214 "src/c.tab.cpp"
    break;

  case 60: /* assignment_expression: unary_expression assignment_operator assignment_expression  */
#line 245 "src/c.y"
                                                                 { (yyval.ast_expression) = ast::allocateBinaryExpression((yyvsp[-2].ast_expression), (yyvsp[-1].ast_operator), (yyvsp[0].ast_expression)); setpos((yyval.ast_expression), &(yyloc)); }
#line 2220 "src/c.tab.cpp"
    break;

  case 61: /* assignment_operator: '='  */
#line 249 "src/c.y"
          { (yyval.ast_operator) = ast::OP_ASSIGN; }
#line 2226 "src/c.tab.cpp"
    break;

  case 62: /* assignment_operator: MUL_ASSIGN  */
#line 250 "src/c.y"
                 { (yyval.ast_operator) = ast::OP_MUL_ASSIGN; }
#line 2232 "src/c.tab.cpp"
    break;

  case 63: /* assignment_operator: DIV_ASSIGN  */
#line 251 "src/c.y"
                 { (yyval.ast_operator) = ast::OP_DIV_ASSIGN; }
#line 2238 "src/c.tab.cpp"
    break;

  case 64: /* assignment_operator: MOD_ASSIGN  */
#line 252 "src/c.y"
                 { (yyval.ast_operator) = ast::OP_MOD_ASSIGN; }
#line 2244 "src/c.tab.cpp"
    break;

  case 65: /* assignment_operator: ADD_ASSIGN  */
#line 253 "src/c.y"
                 { (yyval.ast_operator) = ast::OP_ADD_ASSIGN; }
#line 2250 "src/c.tab.cpp"
    break;

  case 66: /* assignment_operator: SUB_ASSIGN  */
#line 254 "src/c.y"
                 { (yyval.ast_operator) = ast::OP_SUB_ASSIGN; }
#line 2256 "src/c.tab.cpp"
    break;

  case 67: /* assignment_operator: LEFT_ASSIGN  */
#line 255 "src/c.y"
                  { (yyval.ast_operator) = ast::OP_LEFT_ASSIGN; }
#line 2262 "src/c.tab.cpp"
    break;

  case 68: /* assignment_operator: RIGHT_ASSIGN  */
#line 256 "src/c.y"
                   { (yyval.ast_operator) = ast::OP_RIGHT_ASSIGN; }
#line 2268 "src/c.tab.cpp"
    break;

  case 69: /* assignment_operator: AND_ASSIGN  */
#line 257 "src/c.y"
                 { (yyval.ast_operator) = ast::OP_AND_ASSIGN; }
#line 2274 "src/c.tab.cpp"
    break;

  case 70: /* assignment_operator: XOR_ASSIGN  */
#line 258 "src/c.y"
                 { (yyval.ast_operator) = ast::OP_XOR_ASSIGN; }
#line 2280 "src/c.tab.cpp"
    break;

  case 71: /* assignment_operator: OR_ASSIGN  */
#line 259 "src/c.y"
                { (yyval.ast_operator) = ast::OP_OR_ASSIGN; }
#line 2286 "src/c.tab.cpp"
    break;

  case 72: /* expression: assignment_expression  */
#line 263 "src/c.y"
                            { (yyval.ast_expression) = (yyvsp[0].ast_expression); }
#line 2292 "src/c.tab.cpp"
    break;

  case 73: /* expression: expression ',' assignment_expression  */
#line 264 "src/c.y"
                                           { (yyval.ast_expression) = ast::allocateBinaryExpression((yyvsp[-2].ast_expression), ast::OP_SEQ, (yyvsp[0].ast_expression)); setpos((yyval.ast_expression), &(yyloc)); }
#line 2298 "src/c.tab.cpp"
    break;

  case 74: /* constant_expression: conditional_expression  */
#line 268 "src/c.y"
                                 { (yyval.ast_expression) = (yyvsp[0].ast_expression); }
#line 2304 "src/c.tab.cpp"
    break;

  case 75: /* declaration: declaration_specifiers ';'  */
#line 274 "src/c.y"
                                     { (yyval.ast_declaration) = new ast::Declaration((yyvsp[-1].ast_declaration_specifiers), nullptr); setpos((yyval.ast_declaration), &(yyloc)); }
#line 2310 "src/c.tab.cpp"
    break;

  case 76: /* declaration: declaration_specifiers init_declarator_list ';'  */
#line 275 "src/c.y"
                                                          { (yyval.ast_declaration) = new ast::Declaration((yyvsp[-2].ast_declaration_specifiers), (yyvsp[-1].ast_init_declarator_list)); setpos((yyval.ast_declaration), &(yyloc)); }
#line 2316 "src/c.tab.cpp"
    break;

  case 77: /* declaration_specifiers: storage_class_specifier declaration_specifiers  */
#line 279 "src/c.y"
                                                         { (yyvsp[0].ast_declaration_specifiers)->add_storage_specifier((yyvsp[-1].ast_storage_specifier)); (yyval.ast_declaration_specifiers) = (yyvsp[0].ast_declaration_specifiers); setpos((yyval.ast_declaration_specifiers), &(yyloc)); }
#line 2322 "src/c.tab.cpp"
    break;

  case 78: /* declaration_specifiers: storage_class_specifier  */
#line 280 "src/c.y"
                                  { (yyval.ast_declaration_specifiers) = new ast::DeclarationSpecifiers(); (yyval.ast_declaration_specifiers)->add_storage_specifier((yyvsp[0].ast_storage_specifier)); setpos((yyval.ast_declaration_specifiers), &(yyloc)); }
#line 2328 "src/c.tab.cpp"
    break;

  case 79: /* declaration_specifiers: type_specifier declaration_specifiers  */
#line 281 "src/c.y"
                                                { (yyvsp[0].ast_declaration_specifiers)->add_type_specifier((yyvsp[-1].ast_type_specifier)); (yyval.ast_declaration_specifiers) = (yyvsp[0].ast_declaration_specifiers); setpos((yyval.ast_declaration_specifiers), &(yyloc)); }
#line 2334 "src/c.tab.cpp"
    break;

  case 80: /* declaration_specifiers: type_specifier  */
#line 282 "src/c.y"
                         { (yyval.ast_declaration_specifiers) = new ast::DeclarationSpecifiers(); (yyval.ast_declaration_specifiers)->add_type_specifier((yyvsp[0].ast_type_specifier)); setpos((yyval.ast_declaration_specifiers), &(yyloc)); }
#line 2340 "src/c.tab.cpp"
    break;

  case 81: /* declaration_specifiers: type_qualifier declaration_specifiers  */
#line 283 "src/c.y"
                                                { (yyvsp[0].ast_declaration_specifiers)->add_type_qualifier((yyvsp[-1].ast_type_qualifier)); (yyval.ast_declaration_specifiers) = (yyvsp[0].ast_declaration_specifiers); setpos((yyval.ast_declaration_specifiers), &(yyloc)); }
#line 2346 "src/c.tab.cpp"
    break;

  case 82: /* declaration_specifiers: type_qualifier  */
#line 284 "src/c.y"
                         { (yyval.ast_declaration_specifiers) = new ast::DeclarationSpecifiers(); (yyval.ast_declaration_specifiers)->add_type_qualifier((yyvsp[0].ast_type_qualifier)); setpos((yyval.ast_declaration_specifiers), &(yyloc)); }
#line 2352 "src/c.tab.cpp"
    break;

  case 83: /* declaration_specifiers: function_specifier declaration_specifiers  */
#line 285 "src/c.y"
                                                    { (yyvsp[0].ast_declaration_specifiers)->add_func_specifier((yyvsp[-1].ast_function_specifier)); (yyval.ast_declaration_specifiers) = (yyvsp[0].ast_declaration_specifiers); setpos((yyval.ast_declaration_specifiers), &(yyloc)); }
#line 2358 "src/c.tab.cpp"
    break;

  case 84: /* declaration_specifiers: function_specifier  */
#line 286 "src/c.y"
                             { (yyval.ast_declaration_specifiers) = new ast::DeclarationSpecifiers(); (yyval.ast_declaration_specifiers)->add_func_specifier((yyvsp[0].ast_function_specifier)); setpos((yyval.ast_declaration_specifiers), &(yyloc)); }
#line 2364 "src/c.tab.cpp"
    break;

  case 85: /* init_declarator_list: init_declarator  */
#line 290 "src/c.y"
                          { (yyval.ast_init_declarator_list) = new std::vector<ast::InitDeclarator*>(); (yyval.ast_init_declarator_list)->push_back((yyvsp[0].ast_init_declarator)); }
#line 2370 "src/c.tab.cpp"
    break;

  case 86: /* init_declarator_list: init_declarator_list ',' init_declarator  */
#line 291 "src/c.y"
                                                   { (yyvsp[-2].ast_init_declarator_list)->push_back((yyvsp[0].ast_init_declarator)); (yyval.ast_init_declarator_list) = (yyvsp[-2].ast_init_declarator_list); }
#line 2376 "src/c.tab.cpp"
    break;

  case 87: /* init_declarator: pointer_list IDENTIFIER '=' assignment_expression  */
#line 295 "src/c.y"
                                                            { (yyval.ast_init_declarator) = new ast::InitDeclarator((yyvsp[-3].ast_pointer_list), new ast::Identifier((yyvsp[-2].str)), (yyvsp[0].ast_expression)); setpos((yyval.ast_init_declarator), &(yyloc)); }
#line 2382 "src/c.tab.cpp"
    break;

  case 88: /* init_declarator: IDENTIFIER '=' assignment_expression  */
#line 296 "src/c.y"
                                               { (yyval.ast_init_declarator) = new ast::InitDeclarator(0, new ast::Identifier((yyvsp[-2].str)), (yyvsp[0].ast_expression)); setpos((yyval.ast_init_declarator), &(yyloc)); }
#line 2388 "src/c.tab.cpp"
    break;

  case 89: /* init_declarator: pointer_list IDENTIFIER  */
#line 297 "src/c.y"
                                  { (yyval.ast_init_declarator) = new ast::InitDeclarator((yyvsp[-1].ast_pointer_list), new ast::Identifier((yyvsp[0].str)), nullptr); setpos((yyval.ast_init_declarator), &(yyloc)); }
#line 2394 "src/c.tab.cpp"
    break;

  case 90: /* init_declarator: IDENTIFIER  */
#line 298 "src/c.y"
                     { (yyval.ast_init_declarator) = new ast::InitDeclarator(0, new ast::Identifier((yyvsp[0].str)), nullptr); setpos((yyval.ast_init_declarator), &(yyloc)); }
#line 2400 "src/c.tab.cpp"
    break;

  case 91: /* pointer_list: '*' pointer_list  */
#line 302 "src/c.y"
                     { (yyval.ast_pointer_list) = (yyvsp[0].ast_pointer_list) + 1; }
#line 2406 "src/c.tab.cpp"
    break;

  case 92: /* pointer_list: '*'  */
#line 303 "src/c.y"
        { (yyval.ast_pointer_list) = 1; }
#line 2412 "src/c.tab.cpp"
    break;

  case 93: /* storage_class_specifier: EXTERN  */
#line 308 "src/c.y"
                 { (yyval.ast_storage_specifier) = ast::SS_EXTERN; }
#line 2418 "src/c.tab.cpp"
    break;

  case 94: /* storage_class_specifier: STATIC  */
#line 309 "src/c.y"
                 { (yyval.ast_storage_specifier) = ast::SS_STATIC; }
#line 2424 "src/c.tab.cpp"
    break;

  case 95: /* storage_class_specifier: THREAD_LOCAL  */
#line 310 "src/c.y"
                       { (yyval.ast_storage_specifier) = ast::SS_THREADLOCAL; }
#line 2430 "src/c.tab.cpp"
    break;

  case 96: /* storage_class_specifier: AUTO  */
#line 311 "src/c.y"
               { (yyval.ast_storage_specifier) = ast::SS_AUTO; }
#line 2436 "src/c.tab.cpp"
    break;

  case 97: /* storage_class_specifier: REGISTER  */
#line 312 "src/c.y"
                   { (yyval.ast_storage_specifier) = ast::SS_REGISTER; }
#line 2442 "src/c.tab.cpp"
    break;

  case 98: /* type_specifier: VOID  */
#line 316 "src/c.y"
               { (yyval.ast_type_specifier) = ast::TS_VOID; }
#line 2448 "src/c.tab.cpp"
    break;

  case 99: /* type_specifier: CHAR  */
#line 317 "src/c.y"
               { (yyval.ast_type_specifier) = ast::TS_CHAR; }
#line 2454 "src/c.tab.cpp"
    break;

  case 100: /* type_specifier: SHORT  */
#line 318 "src/c.y"
                { (yyval.ast_type_specifier) = ast::TS_SHORT; }
#line 2460 "src/c.tab.cpp"
    break;

  case 101: /* type_specifier: INT  */
#line 319 "src/c.y"
              { (yyval.ast_type_specifier) = ast::TS_INT; }
#line 2466 "src/c.tab.cpp"
    break;

  case 102: /* type_specifier: LONG  */
#line 320 "src/c.y"
               { (yyval.ast_type_specifier) = ast::TS_LONG; }
#line 2472 "src/c.tab.cpp"
    break;

  case 103: /* type_specifier: FLOAT  */
#line 321 "src/c.y"
                { (yyval.ast_type_specifier) = ast::TS_FLOAT; }
#line 2478 "src/c.tab.cpp"
    break;

  case 104: /* type_specifier: DOUBLE  */
#line 322 "src/c.y"
                 { (yyval.ast_type_specifier) = ast::TS_DOUBLE; }
#line 2484 "src/c.tab.cpp"
    break;

  case 105: /* type_specifier: SIGNED  */
#line 323 "src/c.y"
                 { (yyval.ast_type_specifier) = ast::TS_SIGNED; }
#line 2490 "src/c.tab.cpp"
    break;

  case 106: /* type_specifier: UNSIGNED  */
#line 324 "src/c.y"
                   { (yyval.ast_type_specifier) = ast::TS_UNSIGNED; }
#line 2496 "src/c.tab.cpp"
    break;

  case 107: /* type_specifier: BOOL  */
#line 325 "src/c.y"
               { (yyval.ast_type_specifier) = ast::TS_BOOL; }
#line 2502 "src/c.tab.cpp"
    break;

  case 108: /* type_specifier: COMPLEX  */
#line 326 "src/c.y"
                  { (yyval.ast_type_specifier) = ast::TS_COMPLEX; }
#line 2508 "src/c.tab.cpp"
    break;

  case 109: /* type_specifier: IMAGINARY  */
#line 327 "src/c.y"
                    { (yyval.ast_type_specifier) = ast::TS_IMAGINARY; }
#line 2514 "src/c.tab.cpp"
    break;

  case 110: /* type_qualifier: CONST  */
#line 331 "src/c.y"
                { (yyval.ast_type_qualifier) = ast::TQ_CONST; }
#line 2520 "src/c.tab.cpp"
    break;

  case 111: /* type_qualifier: RESTRICT  */
#line 332 "src/c.y"
                   { (yyval.ast_type_qualifier) = ast::TQ_RESTRICT; }
#line 2526 "src/c.tab.cpp"
    break;

  case 112: /* type_qualifier: VOLATILE  */
#line 333 "src/c.y"
                   { (yyval.ast_type_qualifier) = ast::TQ_VOLATILE; }
#line 2532 "src/c.tab.cpp"
    break;

  case 113: /* type_qualifier: ATOMIC  */
#line 334 "src/c.y"
                 { (yyval.ast_type_qualifier) = ast::TQ_ATOMIC; }
#line 2538 "src/c.tab.cpp"
    break;

  case 114: /* function_specifier: INLINE  */
#line 338 "src/c.y"
                 { (yyval.ast_function_specifier) = ast::FS_INLINE; }
#line 2544 "src/c.tab.cpp"
    break;

  case 115: /* function_specifier: NORETURN  */
#line 339 "src/c.y"
                   { (yyval.ast_function_specifier) = ast::FS_NORETURN; }
#line 2550 "src/c.tab.cpp"
    break;

  case 116: /* function_parameter_list: parameter_list ',' ELLIPSIS  */
#line 343 "src/c.y"
                                      { (yyval.ast_function_parameter_list) = new ast::FunctionParameterList((yyvsp[-2].ast_parameter_list), true); }
#line 2556 "src/c.tab.cpp"
    break;

  case 117: /* function_parameter_list: parameter_list  */
#line 344 "src/c.y"
                         { (yyval.ast_function_parameter_list) = new ast::FunctionParameterList((yyvsp[0].ast_parameter_list), false); }
#line 2562 "src/c.tab.cpp"
    break;

  case 118: /* parameter_list: pure_declaration  */
#line 348 "src/c.y"
                           { (yyval.ast_parameter_list) = new std::vector<ast::PureDeclaration*>(); (yyval.ast_parameter_list)->push_back((yyvsp[0].ast_pure_declaration)); }
#line 2568 "src/c.tab.cpp"
    break;

  case 119: /* parameter_list: parameter_list ',' pure_declaration  */
#line 349 "src/c.y"
                                              { (yyvsp[-2].ast_parameter_list)->push_back((yyvsp[0].ast_pure_declaration)); (yyval.ast_parameter_list) = (yyvsp[-2].ast_parameter_list); }
#line 2574 "src/c.tab.cpp"
    break;

  case 120: /* pure_declaration: declaration_specifiers pointer_list IDENTIFIER  */
#line 353 "src/c.y"
                                                         { (yyval.ast_pure_declaration) = new ast::PureDeclaration((yyvsp[-2].ast_declaration_specifiers), (yyvsp[-1].ast_pointer_list), new ast::Identifier((yyvsp[0].str))); setpos((yyval.ast_pure_declaration), &(yyloc)); }
#line 2580 "src/c.tab.cpp"
    break;

  case 121: /* pure_declaration: declaration_specifiers IDENTIFIER  */
#line 354 "src/c.y"
                                            { (yyval.ast_pure_declaration) = new ast::PureDeclaration((yyvsp[-1].ast_declaration_specifiers), 0, new ast::Identifier((yyvsp[0].str))); setpos((yyval.ast_pure_declaration), &(yyloc)); }
#line 2586 "src/c.tab.cpp"
    break;

  case 122: /* statement: labeled_statement  */
#line 360 "src/c.y"
                            { (yyval.ast_statement) = (yyvsp[0].ast_statement); setpos((yyval.ast_statement), &(yyloc)); }
#line 2592 "src/c.tab.cpp"
    break;

  case 123: /* statement: declaration_statement  */
#line 361 "src/c.y"
                          { (yyval.ast_statement) = (yyvsp[0].ast_declaration_statement); setpos((yyval.ast_statement), &(yyloc)); }
#line 2598 "src/c.tab.cpp"
    break;

  case 124: /* statement: compound_statement  */
#line 362 "src/c.y"
                             { (yyval.ast_statement) = (yyvsp[0].ast_block_statement); setpos((yyval.ast_statement), &(yyloc)); }
#line 2604 "src/c.tab.cpp"
    break;

  case 125: /* statement: expression_statement  */
#line 363 "src/c.y"
                               { (yyval.ast_statement) = (yyvsp[0].ast_expression_statement); setpos((yyval.ast_statement), &(yyloc)); }
#line 2610 "src/c.tab.cpp"
    break;

  case 126: /* statement: selection_statement  */
#line 364 "src/c.y"
                              { (yyval.ast_statement) = (yyvsp[0].ast_statement); setpos((yyval.ast_statement), &(yyloc)); }
#line 2616 "src/c.tab.cpp"
    break;

  case 127: /* statement: iteration_statement  */
#line 365 "src/c.y"
                              { (yyval.ast_statement) = (yyvsp[0].ast_statement); setpos((yyval.ast_statement), &(yyloc)); }
#line 2622 "src/c.tab.cpp"
    break;

  case 128: /* statement: jump_statement  */
#line 366 "src/c.y"
                         { (yyval.ast_statement) = (yyvsp[0].ast_statement); setpos((yyval.ast_statement), &(yyloc)); }
#line 2628 "src/c.tab.cpp"
    break;

  case 129: /* declaration_statement: declaration  */
#line 370 "src/c.y"
                { (yyval.ast_declaration_statement) = new ast::DeclarationStatement((yyvsp[0].ast_declaration)); setpos((yyval.ast_declaration_statement), &(yyloc)); }
#line 2634 "src/c.tab.cpp"
    break;

  case 130: /* labeled_statement: IDENTIFIER ':' statement  */
#line 373 "src/c.y"
                                   { (yyval.ast_statement) = new ast::LabeledStatement(new ast::Identifier((yyvsp[-2].str)), (yyvsp[0].ast_statement)); setpos((yyval.ast_statement), &(yyloc)); }
#line 2640 "src/c.tab.cpp"
    break;

  case 131: /* labeled_statement: CASE constant_expression ':' statement  */
#line 374 "src/c.y"
                                                 { (yyval.ast_statement) = new ast::CaseStatement((yyvsp[-2].ast_expression), (yyvsp[0].ast_statement)); setpos((yyval.ast_statement), &(yyloc)); }
#line 2646 "src/c.tab.cpp"
    break;

  case 132: /* labeled_statement: DEFAULT ':' statement  */
#line 375 "src/c.y"
                                { (yyval.ast_statement) = (yyvsp[0].ast_statement); setpos((yyval.ast_statement), &(yyloc)); }
#line 2652 "src/c.tab.cpp"
    break;

  case 133: /* compound_statement: '{' block_item_list '}'  */
#line 379 "src/c.y"
                            { (yyval.ast_block_statement) = (yyvsp[-1].ast_block_statement); setpos((yyval.ast_block_statement), &(yyloc)); }
#line 2658 "src/c.tab.cpp"
    break;

  case 134: /* compound_statement: '{' '}'  */
#line 380 "src/c.y"
            { (yyval.ast_block_statement) = new ast::BlockStatement(); setpos((yyval.ast_block_statement), &(yyloc)); }
#line 2664 "src/c.tab.cpp"
    break;

  case 135: /* block_item_list: statement  */
#line 384 "src/c.y"
                               { (yyval.ast_block_statement) = new ast::BlockStatement(); (yyval.ast_block_statement)->push_back((yyvsp[0].ast_statement)); setpos((yyval.ast_block_statement), &(yyloc)); }
#line 2670 "src/c.tab.cpp"
    break;

  case 136: /* block_item_list: block_item_list statement  */
#line 385 "src/c.y"
                               { (yyvsp[-1].ast_block_statement)->push_back((yyvsp[0].ast_statement)); (yyval.ast_block_statement) = (yyvsp[-1].ast_block_statement); setpos((yyval.ast_block_statement), &(yyloc)); }
#line 2676 "src/c.tab.cpp"
    break;

  case 137: /* expression_statement: ';'  */
#line 388 "src/c.y"
              { (yyval.ast_expression_statement) = new ast::ExpressionStatement(nullptr); setpos((yyval.ast_expression_statement), &(yyloc)); }
#line 2682 "src/c.tab.cpp"
    break;

  case 138: /* expression_statement: expression ';'  */
#line 389 "src/c.y"
                         { (yyval.ast_expression_statement) = new ast::ExpressionStatement((yyvsp[-1].ast_expression)); setpos((yyval.ast_expression_statement), &(yyloc)); }
#line 2688 "src/c.tab.cpp"
    break;

  case 139: /* selection_statement: IF '(' expression ')' statement ELSE statement  */
#line 393 "src/c.y"
                                                         { (yyval.ast_statement) = new ast::IfStatement((yyvsp[-4].ast_expression), (yyvsp[-2].ast_statement), (yyvsp[0].ast_statement)); setpos((yyval.ast_statement), &(yyloc)); }
#line 2694 "src/c.tab.cpp"
    break;

  case 140: /* selection_statement: IF '(' expression ')' statement  */
#line 394 "src/c.y"
                                          { (yyval.ast_statement) = new ast::IfStatement((yyvsp[-2].ast_expression), (yyvsp[0].ast_statement), nullptr); setpos((yyval.ast_statement), &(yyloc)); }
#line 2700 "src/c.tab.cpp"
    break;

  case 141: /* selection_statement: SWITCH '(' expression ')' statement  */
#line 395 "src/c.y"
                                              { (yyval.ast_statement) = new ast::SwitchStatement((yyvsp[-2].ast_expression), (yyvsp[0].ast_statement)); setpos((yyval.ast_statement), &(yyloc)); }
#line 2706 "src/c.tab.cpp"
    break;

  case 142: /* iteration_statement: WHILE '(' expression ')' statement  */
#line 399 "src/c.y"
                                             { (yyval.ast_statement) = new ast::WhileStatement((yyvsp[-2].ast_expression), (yyvsp[0].ast_statement)); setpos((yyval.ast_statement), &(yyloc)); }
#line 2712 "src/c.tab.cpp"
    break;

  case 143: /* iteration_statement: DO statement WHILE '(' expression ')' ';'  */
#line 400 "src/c.y"
                                                    { (yyval.ast_statement) = new ast::DoWhileStatement((yyvsp[-2].ast_expression), (yyvsp[-5].ast_statement)); setpos((yyval.ast_statement), &(yyloc)); }
#line 2718 "src/c.tab.cpp"
    break;

  case 144: /* jump_statement: GOTO IDENTIFIER ';'  */
#line 404 "src/c.y"
                              { (yyval.ast_statement) = new ast::GotoStatement((yyvsp[-1].str)); setpos((yyval.ast_statement), &(yyloc)); }
#line 2724 "src/c.tab.cpp"
    break;

  case 145: /* jump_statement: CONTINUE ';'  */
#line 405 "src/c.y"
                       { (yyval.ast_statement) = new ast::ContinueStatement(); setpos((yyval.ast_statement), &(yyloc)); }
#line 2730 "src/c.tab.cpp"
    break;

  case 146: /* jump_statement: BREAK ';'  */
#line 406 "src/c.y"
                    { (yyval.ast_statement) = new ast::BreakStatement(); setpos((yyval.ast_statement), &(yyloc)); }
#line 2736 "src/c.tab.cpp"
    break;

  case 147: /* jump_statement: RETURN ';'  */
#line 407 "src/c.y"
                     { (yyval.ast_statement) = new ast::ReturnStatement(nullptr); setpos((yyval.ast_statement), &(yyloc)); }
#line 2742 "src/c.tab.cpp"
    break;

  case 148: /* jump_statement: RETURN expression ';'  */
#line 408 "src/c.y"
                                { (yyval.ast_statement) = new ast::ReturnStatement((yyvsp[-1].ast_expression)); setpos((yyval.ast_statement), &(yyloc)); }
#line 2748 "src/c.tab.cpp"
    break;

  case 149: /* translation_unit: function_definition  */
#line 414 "src/c.y"
                              { (yyval.ast_translation_unit) = new ast::TranslationUnit(); (yyval.ast_translation_unit)->add_function((yyvsp[0].ast_function)); *tu = *(yyval.ast_translation_unit); setpos((yyval.ast_translation_unit), &(yyloc)); }
#line 2754 "src/c.tab.cpp"
    break;

  case 150: /* translation_unit: function_declaration  */
#line 415 "src/c.y"
                           { (yyval.ast_translation_unit) = new ast::TranslationUnit(); (yyval.ast_translation_unit)->add_function((yyvsp[0].ast_function)); *tu = *(yyval.ast_translation_unit); setpos((yyval.ast_translation_unit), &(yyloc)); }
#line 2760 "src/c.tab.cpp"
    break;

  case 151: /* translation_unit: declaration  */
#line 416 "src/c.y"
                      { (yyval.ast_translation_unit) = new ast::TranslationUnit(); (yyval.ast_translation_unit)->add_declaration(new ast::DeclarationStatement((yyvsp[0].ast_declaration))); *tu = *(yyval.ast_translation_unit); setpos((yyval.ast_translation_unit), &(yyloc)); }
#line 2766 "src/c.tab.cpp"
    break;

  case 152: /* translation_unit: translation_unit function_definition  */
#line 417 "src/c.y"
                                               { (yyvsp[-1].ast_translation_unit)->add_function((yyvsp[0].ast_function)); (yyval.ast_translation_unit) = (yyvsp[-1].ast_translation_unit); *tu = *(yyval.ast_translation_unit); setpos((yyval.ast_translation_unit), &(yyloc)); }
#line 2772 "src/c.tab.cpp"
    break;

  case 153: /* translation_unit: translation_unit function_declaration  */
#line 418 "src/c.y"
                                            { (yyvsp[-1].ast_translation_unit)->add_function((yyvsp[0].ast_function)); (yyval.ast_translation_unit) = (yyvsp[-1].ast_translation_unit); *tu = *(yyval.ast_translation_unit); setpos((yyval.ast_translation_unit), &(yyloc)); }
#line 2778 "src/c.tab.cpp"
    break;

  case 154: /* translation_unit: translation_unit declaration  */
#line 419 "src/c.y"
                                       { (yyvsp[-1].ast_translation_unit)->add_declaration(new ast::DeclarationStatement((yyvsp[0].ast_declaration))); (yyval.ast_translation_unit) = (yyvsp[-1].ast_translation_unit); *tu = *(yyval.ast_translation_unit); setpos((yyval.ast_translation_unit), &(yyloc)); }
#line 2784 "src/c.tab.cpp"
    break;

  case 155: /* function_definition: pure_declaration '(' function_parameter_list ')' compound_statement  */
#line 423 "src/c.y"
                                                                        { (yyval.ast_function) = new ast::Function((yyvsp[-4].ast_pure_declaration), (yyvsp[-2].ast_function_parameter_list), (yyvsp[0].ast_block_statement)); setpos((yyval.ast_function), &(yyloc)); }
#line 2790 "src/c.tab.cpp"
    break;

  case 156: /* function_definition: pure_declaration '(' ')' compound_statement  */
#line 424 "src/c.y"
                                                { (yyval.ast_function) = new ast::Function((yyvsp[-3].ast_pure_declaration), nullptr, (yyvsp[0].ast_block_statement)); setpos((yyval.ast_function), &(yyloc)); }
#line 2796 "src/c.tab.cpp"
    break;

  case 157: /* function_definition: pure_declaration '(' VOID ')' compound_statement  */
#line 425 "src/c.y"
                                                     { (yyval.ast_function) = new ast::Function((yyvsp[-4].ast_pure_declaration), nullptr, (yyvsp[0].ast_block_statement)); setpos((yyval.ast_function), &(yyloc)); }
#line 2802 "src/c.tab.cpp"
    break;

  case 158: /* function_declaration: pure_declaration '(' function_parameter_list ')' ';'  */
#line 429 "src/c.y"
                                                         { (yyval.ast_function) = new ast::Function((yyvsp[-4].ast_pure_declaration), (yyvsp[-2].ast_function_parameter_list), nullptr); setpos((yyval.ast_function), &(yyloc)); }
#line 2808 "src/c.tab.cpp"
    break;

  case 159: /* function_declaration: pure_declaration '(' ')' ';'  */
#line 430 "src/c.y"
                                 { (yyval.ast_function) = new ast::Function((yyvsp[-3].ast_pure_declaration), nullptr, nullptr); setpos((yyval.ast_function), &(yyloc)); }
#line 2814 "src/c.tab.cpp"
    break;

  case 160: /* function_declaration: pure_declaration '(' VOID ')' ';'  */
#line 431 "src/c.y"
                                      { (yyval.ast_function) = new ast::Function((yyvsp[-4].ast_pure_declaration), nullptr, nullptr); setpos((yyval.ast_function), &(yyloc)); }
#line 2820 "src/c.tab.cpp"
    break;


#line 2824 "src/c.tab.cpp"

      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", YY_CAST (yysymbol_kind_t, yyr1[yyn]), &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;

  *++yyvsp = yyval;
  *++yylsp = yyloc;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */
  {
    const int yylhs = yyr1[yyn] - YYNTOKENS;
    const int yyi = yypgoto[yylhs] + *yyssp;
    yystate = (0 <= yyi && yyi <= YYLAST && yycheck[yyi] == *yyssp
               ? yytable[yyi]
               : yydefgoto[yylhs]);
  }

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYSYMBOL_YYEMPTY : YYTRANSLATE (yychar);
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
      {
        yypcontext_t yyctx
          = {yyssp, yytoken, &yylloc};
        char const *yymsgp = YY_("syntax error");
        int yysyntax_error_status;
        yysyntax_error_status = yysyntax_error (&yymsg_alloc, &yymsg, &yyctx);
        if (yysyntax_error_status == 0)
          yymsgp = yymsg;
        else if (yysyntax_error_status == -1)
          {
            if (yymsg != yymsgbuf)
              YYSTACK_FREE (yymsg);
            yymsg = YY_CAST (char *,
                             YYSTACK_ALLOC (YY_CAST (YYSIZE_T, yymsg_alloc)));
            if (yymsg)
              {
                yysyntax_error_status
                  = yysyntax_error (&yymsg_alloc, &yymsg, &yyctx);
                yymsgp = yymsg;
              }
            else
              {
                yymsg = yymsgbuf;
                yymsg_alloc = sizeof yymsgbuf;
                yysyntax_error_status = YYENOMEM;
              }
          }
        yyerror (tu, yymsgp);
        if (yysyntax_error_status == YYENOMEM)
          YYNOMEM;
      }
    }

  yyerror_range[1] = yylloc;
  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= YYEOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == YYEOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval, &yylloc, tu);
          yychar = YYEMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:
  /* Pacify compilers when the user code never invokes YYERROR and the
     label yyerrorlab therefore never appears in user code.  */
  if (0)
    YYERROR;
  ++yynerrs;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  /* Pop stack until we find a state that shifts the error token.  */
  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYSYMBOL_YYerror;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYSYMBOL_YYerror)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;

      yyerror_range[1] = *yylsp;
      yydestruct ("Error: popping",
                  YY_ACCESSING_SYMBOL (yystate), yyvsp, yylsp, tu);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  yyerror_range[2] = yylloc;
  ++yylsp;
  YYLLOC_DEFAULT (*yylsp, yyerror_range, 2);

  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", YY_ACCESSING_SYMBOL (yyn), yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturnlab;


/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturnlab;


/*-----------------------------------------------------------.
| yyexhaustedlab -- YYNOMEM (memory exhaustion) comes here.  |
`-----------------------------------------------------------*/
yyexhaustedlab:
  yyerror (tu, YY_("memory exhausted"));
  yyresult = 2;
  goto yyreturnlab;


/*----------------------------------------------------------.
| yyreturnlab -- parsing is finished, clean up and return.  |
`----------------------------------------------------------*/
yyreturnlab:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval, &yylloc, tu);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  YY_ACCESSING_SYMBOL (+*yyssp), yyvsp, yylsp, tu);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
  return yyresult;
}

#line 434 "src/c.y"

#include <stdio.h>

void yyerror(ast::TranslationUnit* tu, const char *s)
{
  YYLTYPE info = yylloc;
  ehdl::err(s, {info.first_line, info.last_line, info.first_column, info.last_column});
}


void setpos(ast::Node *n, void* info_v) {
    YYLTYPE info = *((YYLTYPE*)info_v);
    n->pos.first_line = info.first_line;
    n->pos.last_line = info.last_line;
    n->pos.first_column = info.first_column;
    n->pos.last_column = info.last_column;
}
